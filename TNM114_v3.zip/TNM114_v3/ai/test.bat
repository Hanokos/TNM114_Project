@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo AI environment is missing.
  echo Run setup.bat first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" test_connection.py
if errorlevel 1 (
  echo.
  echo Connection test failed.
  echo Make sure Godot is running before starting this test.
  pause
  exit /b 1
)
pause
