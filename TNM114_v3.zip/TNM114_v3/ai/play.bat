@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo AI environment is missing.
  echo Run setup.bat first.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" play.py
pause
