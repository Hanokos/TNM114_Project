from __future__ import annotations

import base64
import json
import socket
from typing import Any

import gymnasium as gym
import numpy as np
from gymnasium import spaces


class GodotDroneEnv(gym.Env[np.ndarray, int]):
    """Gymnasium environment controlling the running Godot simulator over TCP."""

    metadata = {"render_modes": []}

    def __init__(self, host: str = "127.0.0.1", port: int = 5000, max_steps: int = 900):
        super().__init__()
        self.host = host
        self.port = port
        self.max_steps = max_steps
        self.step_count = 0
        self.episode_count = 0
        self.sock: socket.socket | None = None
        self._rx_buffer = b""

        self.observation_space = spaces.Box(
            low=-1.0,
            high=1.0,
            shape=(72,),
            dtype=np.float32,
        )
        self.action_space = spaces.Discrete(8)
        self._connect()

    def _connect(self) -> None:
        self.close()
        self.sock = socket.create_connection((self.host, self.port), timeout=10.0)
        self.sock.settimeout(60.0)
        self._rx_buffer = b""
        hello = self._read_line()
        try:
            decoded = base64.b64decode(hello, validate=True)
            message = json.loads(decoded.decode("utf-8"))
        except Exception as exc:
            self.close()
            raise RuntimeError(f"Invalid hello from Godot: {hello[:120]!r}") from exc
        if message.get("type") != "hello":
            self.close()
            raise RuntimeError(f"Unexpected first message from Godot: {message!r}")

    def _read_line(self) -> bytes:
        assert self.sock is not None
        while True:
            newline = self._rx_buffer.find(b"\n")
            if newline >= 0:
                line = self._rx_buffer[:newline]
                self._rx_buffer = self._rx_buffer[newline + 1:]
                return line.strip()
            chunk = self.sock.recv(4096)
            if not chunk:
                raise ConnectionError("Godot closed the RL connection.")
            self._rx_buffer += chunk
            if len(self._rx_buffer) > 1_000_000:
                raise ConnectionError("Godot RL response buffer became too large.")

    def _send(self, message: dict[str, Any]) -> dict[str, Any]:
        if self.sock is None:
            self._connect()

        payload = (json.dumps(message, separators=(",", ":"), ensure_ascii=True) + "\n").encode("ascii")
        assert self.sock is not None
        self.sock.sendall(payload)

        line = self._read_line()
        try:
            decoded = base64.b64decode(line, validate=True)
            response = json.loads(decoded.decode("utf-8"))
        except (ValueError, UnicodeDecodeError, json.JSONDecodeError) as exc:
            raise RuntimeError(f"Invalid response from Godot: {line[:120]!r}") from exc

        if response.get("type") == "error":
            raise RuntimeError(response.get("message", "Unknown Godot error"))
        return response

    @staticmethod
    def _observation(values: list[float]) -> np.ndarray:
        obs = np.asarray(values, dtype=np.float32)
        if obs.shape != (72,):
            raise ValueError(f"Expected 72 observation values, got {obs.shape}")
        return np.clip(obs, -1.0, 1.0)

    def reset(self, *, seed: int | None = None, options: dict[str, Any] | None = None):
        super().reset(seed=seed)
        self.step_count = 0
        self.episode_count += 1
        try:
            response = self._send({"cmd": "reset"})
        except (TimeoutError, ConnectionError, OSError):
            self._connect()
            response = self._send({"cmd": "reset"})
        obs = self._observation(response["observation"])
        return obs, {
            "run": response.get("run", 0),
            "episode": self.episode_count,
            "level": response.get("level", 1),
            "obstacles": response.get("obstacles", 0),
            "level_success_rate": response.get("level_success_rate", 0.0),
            "level_mean_checkpoints": response.get("level_mean_checkpoints", 0.0),
            "level_mean_efficiency": response.get("level_mean_efficiency", 0.0),
            "level_requirements_met": response.get("level_requirements_met", False),
            "level_window": response.get("level_window", 0),
            "training_complete": response.get("training_complete", False),
        }

    def step(self, action: int):
        action = int(action)
        if not self.action_space.contains(action):
            raise ValueError(f"Invalid action: {action}")

        self.step_count += 1
        response = self._send({"cmd": "step", "action": action})
        obs = self._observation(response["observation"])
        reward = float(response["reward"])
        terminated = bool(response["done"])
        truncated = False

        # Convert Gymnasium's time limit into a real failed episode in Godot so
        # curriculum statistics count it as a failure instead of silently resetting.
        if not terminated and self.step_count >= self.max_steps:
            timeout_response = self._send({"cmd": "timeout"})
            terminated = bool(timeout_response.get("done", True))
            truncated = True
            response = timeout_response
            obs = self._observation(response["observation"])
            reward = float(response.get("reward", reward))

        episode_stats = response.get("episode_stats", {})
        reported_level = int(episode_stats.get("level", response.get("level", 1))) if episode_stats else int(response.get("level", 1))
        reported_success_rate = float(episode_stats.get("level_success_rate", response.get("level_success_rate", 0.0))) if episode_stats else float(response.get("level_success_rate", 0.0))
        reported_mean_checkpoints = float(episode_stats.get("level_mean_checkpoints", response.get("level_mean_checkpoints", 0.0))) if episode_stats else float(response.get("level_mean_checkpoints", 0.0))
        reported_mean_efficiency = float(episode_stats.get("level_mean_efficiency", response.get("level_mean_efficiency", 0.0))) if episode_stats else float(response.get("level_mean_efficiency", 0.0))
        reported_requirements_met = bool(episode_stats.get("level_requirements_met", response.get("level_requirements_met", False))) if episode_stats else bool(response.get("level_requirements_met", False))
        reported_window = int(episode_stats.get("level_window", response.get("level_window", 0))) if episode_stats else int(response.get("level_window", 0))
        info = {
            "step": self.step_count,
            "checkpoint_index": float(obs[10]),
            "level": reported_level,
            "level_success_rate": reported_success_rate,
            "level_mean_checkpoints": reported_mean_checkpoints,
            "level_mean_efficiency": reported_mean_efficiency,
            "level_requirements_met": reported_requirements_met,
            "level_window": reported_window,
            "training_complete": bool(response.get("training_complete", False)),
            "death": bool(episode_stats) and episode_stats.get("reason") == "death",
            "success": bool(episode_stats) and bool(episode_stats.get("success", False)),
            "checkpoint_reached": response.get("checkpoint_reached", 0),
            "episode_stats": episode_stats,
        }

        return obs, reward, terminated, truncated, info

    def close(self) -> None:
        if self.sock is not None:
            try:
                self.sock.shutdown(socket.SHUT_RDWR)
            except OSError:
                pass
            try:
                self.sock.close()
            except OSError:
                pass
            self.sock = None
        self._rx_buffer = b""
