from pathlib import Path

from stable_baselines3 import PPO

from godot_env import GodotDroneEnv


ROOT = Path(__file__).resolve().parent
MODEL = ROOT / "models" / "drone_ppo_final.zip"


def main() -> None:
    if not MODEL.exists():
        raise FileNotFoundError(
            f"No trained model found at {MODEL}. Run train.py first."
        )

    env = GodotDroneEnv(max_steps=900)
    model = PPO.load(MODEL)
    obs, _ = env.reset()

    try:
        while True:
            action, _ = model.predict(obs, deterministic=True)
            obs, reward, terminated, truncated, _ = env.step(int(action))
            if terminated or truncated:
                obs, _ = env.reset()
    except KeyboardInterrupt:
        print("Stopped.")
    finally:
        env.close()


if __name__ == "__main__":
    main()
