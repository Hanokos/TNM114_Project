class_name Drone
extends CharacterBody3D

signal killed

@export var speed: float = 11.0
var manual_control: bool = true
var rl_action: int = 0
var alive: bool = true

func _ready() -> void:
    collision_layer = 1
    collision_mask = 1
    setup_visuals()

func setup_visuals() -> void:
    for child: Node in get_children():
        if child is MeshInstance3D or child is OmniLight3D:
            child.queue_free()

    var body_mesh := MeshInstance3D.new()
    body_mesh.name = "DroneBody"
    var box := BoxMesh.new()
    box.size = Vector3(1.5, 0.45, 1.0)
    body_mesh.mesh = box
    body_mesh.material_override = _drone_material(Color("4fa3ff"))
    add_child(body_mesh)

    var rotor_positions: Array[Vector3] = [
        Vector3(-0.75, 0.05, -0.55),
        Vector3(0.75, 0.05, -0.55),
        Vector3(-0.75, 0.05, 0.55),
        Vector3(0.75, 0.05, 0.55)
    ]
    for rotor_position: Vector3 in rotor_positions:
        var rotor := MeshInstance3D.new()
        var cylinder := CylinderMesh.new()
        cylinder.top_radius = 0.22
        cylinder.bottom_radius = 0.22
        cylinder.height = 0.08
        rotor.mesh = cylinder
        rotor.position = rotor_position
        rotor.material_override = _drone_material(Color("222b3a"))
        add_child(rotor)

    var light := OmniLight3D.new()
    light.name = "DroneLight"
    light.light_color = Color("4fa3ff")
    light.light_energy = 1.5
    light.omni_range = 5.0
    add_child(light)

func reset_for_run(new_position: Vector3) -> void:
    global_position = new_position
    velocity = Vector3.ZERO
    manual_control = true
    rl_action = 0
    alive = true
    set_physics_process(true)

func _physics_process(_delta: float) -> void:
    if not manual_control or not alive:
        return

    var direction: Vector3 = Vector3.ZERO
    if Input.is_key_pressed(KEY_W):
        direction.z -= 1.0
    if Input.is_key_pressed(KEY_S):
        direction.z += 1.0
    if Input.is_key_pressed(KEY_A):
        direction.x -= 1.0
    if Input.is_key_pressed(KEY_D):
        direction.x += 1.0
    if Input.is_key_pressed(KEY_Q):
        direction.y -= 1.0
    if Input.is_key_pressed(KEY_E):
        direction.y += 1.0

    if direction.length_squared() > 1.0:
        direction = direction.normalized()
    velocity = direction * speed
    move_and_slide()

func action_direction(action: int) -> Vector3:
    match action:
        0: return Vector3(0.0, 0.0, -1.0)
        1: return Vector3(-1.0, 0.0, -1.0).normalized()
        2: return Vector3(1.0, 0.0, -1.0).normalized()
        3: return Vector3(0.0, 1.0, 0.0)
        4: return Vector3(0.0, -1.0, 0.0)
        5: return Vector3(0.0, 0.0, 1.0)
        6: return Vector3(-1.0, 0.0, 0.0)
        7: return Vector3(1.0, 0.0, 0.0)
        _ : return Vector3.ZERO

func apply_rl_action(action: int) -> void:
    if not alive:
        return
    rl_action = action
    var direction := action_direction(action)
    velocity = direction * speed
    move_and_slide()

func _goal_relative_direction(action: int, target_position: Vector3) -> Vector3:
    var to_target: Vector3 = target_position - global_position
    if to_target.length_squared() < 0.0001:
        return Vector3.ZERO

    var forward: Vector3 = to_target.normalized()
    var horizontal_forward := Vector3(forward.x, 0.0, forward.z)
    if horizontal_forward.length_squared() < 0.01:
        horizontal_forward = Vector3.FORWARD
    horizontal_forward = horizontal_forward.normalized()
    var left := Vector3.UP.cross(horizontal_forward).normalized()

    # Actions are goal-relative instead of fixed to world axes. Action 0 always
    # means "go toward the current checkpoint". The other actions are controlled
    # detours around that goal direction. This dramatically reduces aimless
    # exploration and makes obstacle avoidance a local decision: left, right, up
    # or down around the object, then back toward the checkpoint.
    match action:
        0: return forward
        1: return (forward + left * 0.85).normalized()
        2: return (forward - left * 0.85).normalized()
        3: return (forward + Vector3.UP * 0.85).normalized()
        4: return (forward - Vector3.UP * 0.85).normalized()
        5: return left
        6: return -left
        7: return -forward
        _: return forward

func simulate_rl_tick(action: int, delta_seconds: float, target_position: Vector3 = Vector3.ZERO) -> KinematicCollision3D:
    if not alive:
        return null
    manual_control = false
    rl_action = action
    var direction := _goal_relative_direction(action, target_position)
    velocity = direction * speed
    var collision: KinematicCollision3D = move_and_collide(direction * speed * delta_seconds)
    return collision

func stop() -> void:
    velocity = Vector3.ZERO
    manual_control = false
    alive = false
    set_physics_process(false)

func _drone_material(material_color: Color) -> StandardMaterial3D:
    var material := StandardMaterial3D.new()
    material.albedo_color = material_color
    return material
