@echo off
setlocal
cd /d "%~dp0"

echo ============================================================
echo TNM114_v4 - MANUAL-STYLE PYTHON SETUP
echo ============================================================
echo.
echo This runs the same commands as a manual Visual Studio terminal setup.
echo No PowerShell setup script is used.
echo.

if not exist ".venv\Scripts\python.exe" (
    echo [1/6] Creating Python 3.13 virtual environment...
    py -3.13 -m venv .venv
    if errorlevel 1 goto :fail
) else (
    echo [1/6] Existing .venv found - keeping it.
)

echo.
echo [2/6] Installing NumPy...
call ".venv\Scripts\python.exe" -m pip install numpy --disable-pip-version-check --no-input --retries 5 --timeout 120
if errorlevel 1 goto :fail

echo.
echo [3/6] Installing Gymnasium...
call ".venv\Scripts\python.exe" -m pip install "gymnasium>=1.0,<2.0" --disable-pip-version-check --no-input --retries 5 --timeout 120
if errorlevel 1 goto :fail

echo.
echo [4/6] Installing Stable-Baselines3 + PyTorch...
call ".venv\Scripts\python.exe" -m pip install "stable-baselines3>=2.7.0,<3.0" --disable-pip-version-check --no-input --retries 5 --timeout 120
if errorlevel 1 goto :fail

echo.
echo [5/6] Installing TensorBoard...
call ".venv\Scripts\python.exe" -m pip install tensorboard --disable-pip-version-check --no-input --retries 5 --timeout 120
if errorlevel 1 goto :fail

echo.
echo [6/6] Verifying the complete RL stack...
call ".venv\Scripts\python.exe" -c "import numpy; import numpy.typing; import gymnasium; import stable_baselines3; import tensorboard; import torch; print('ALL RL PACKAGES OK'); print('NumPy:', numpy.__version__); print('Gymnasium:', gymnasium.__version__); print('Stable-Baselines3:', stable_baselines3.__version__); print('Torch:', torch.__version__)"
if errorlevel 1 goto :fail

echo.
echo ============================================================
echo SETUP COMPLETE
 echo ============================================================
echo.
echo Next:
echo   1. Open Godot and press Play.
echo   2. Run: .\test.bat
echo   3. If the test passes, run: .\train.bat
echo.
pause
exit /b 0

:fail
echo.
echo ============================================================
echo SETUP FAILED
 echo ============================================================
echo The command above failed. Nothing else is being hidden.
echo If needed, run that exact command manually in this terminal.
echo.
pause
exit /b 1
