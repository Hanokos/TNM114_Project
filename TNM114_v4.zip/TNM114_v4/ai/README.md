# TNM114_v4 AI

## Setup

Open a Visual Studio terminal in this `ai` folder and run:

```powershell
.\setup.bat
```

The batch file deliberately uses the same direct commands that worked during manual setup:

```text
py -3.13 -m venv .venv
.venv\Scripts\python.exe -m pip install numpy
.venv\Scripts\python.exe -m pip install gymnasium
.venv\Scripts\python.exe -m pip install stable-baselines3
.venv\Scripts\python.exe -m pip install tensorboard
```

There is no PowerShell installer and no `ensurepip` step.

You do not need to activate `.venv`.

## Run

1. Open the Godot project and press **Play**.
2. In this folder run:

```powershell
.\test.bat
```

3. If the protocol test passes:

```powershell
.\train.bat
```

4. To run the saved policy:

```powershell
.\play.bat
```

## Training design

### Goal-driven learning

The observation contains:

- current checkpoint number
- current curriculum level
- direction to the active checkpoint/finish
- distance to the active goal
- drone velocity
- obstacle sensors
- distances to the arena boundaries

### Reward

- progress toward goal: positive
- moving away from goal: negative
- time: small negative reward every RL step
- checkpoint: +100
- finish: +500
- collision/out-of-bounds/time-limit: -180
- close obstacle: small warning penalty

### Curriculum

There are 10 levels.

| Level | Obstacles |
|---:|---:|
| 1 | 5 |
| 2 | 11 |
| 3 | 17 |
| 4 | 23 |
| 5 | 29 |
| 6 | 36 |
| 7 | 42 |
| 8 | 48 |
| 9 | 54 |
| 10 | 60 |

Each episode gets a new random airspace while keeping the same obstacle count for the current level.

A level is evaluated on the **latest 20 completed episodes**. It is cleared only when all three conditions are true:

- **success rate >= 95%**
- **mean checkpoints >= 4.0 / 5.0**
- **mean path efficiency >= 65%**

A successful episode means reaching all 5 checkpoints and the finish. When a level is cleared, the next episode starts on the next level. After Level 10 satisfies the same three gates, training stops and the final top-5 report is printed.

The generator keeps checkpoints safe but deliberately places a small number of obstacles near the direct checkpoint route. This forces learnable detours while leaving plenty of space to go around them.

## Training output

Every PPO rollout is treated as a **PPO iteration/batch**.

Each report contains:

- mean reward/score for the episodes completed in that batch
- mean lifetime in RL steps and seconds
- mean checkpoints reached
- mean success rate
- best reward in that batch + episode + PPO iteration
- longest lifetime + episode + PPO iteration
- most checkpoints + episode + PPO iteration
- fastest successful finish
- top 5 episodes in the batch
- current level and its 20-episode rolling evaluation window
- rolling success rate, mean checkpoints, and mean path efficiency

At the end of the whole curriculum, the terminal prints the top 5 episodes of the full training run.

## What is an RL step?

One RL step is one decision from PPO. Godot holds that action for 10 physics ticks at 30 Hz, so one RL step is approximately 0.333 seconds of simulated flight.

For example:

```text
ep_len_mean = 397
```

means the average completed episode lasted about 397 AI decisions, not 397 seconds.


### v2.4 behavior learning

The environment now deliberately places a small fraction of obstacles near the direct route. The agent must learn to use the denser obstacle sensors and choose a detour. Reward shaping penalizes time, dangerous proximity, and inefficient paths while rewarding checkpoint progress and successful completion.


## v2.4 goal-directed control

v2.4 changes the action space semantics without increasing the number of actions. Actions are relative to the current checkpoint/finish:

- 0 = fly directly toward the current goal
- 1/2 = goal + left/right detour
- 3/4 = goal + up/down detour
- 5/6 = pure left/right strafe
- 7 = move backward from the goal

This means the policy no longer has to discover the meaning of world-axis actions before it can learn the task. The observation is also expanded to 72 values and explicitly contains the drone position, target position, target direction, target distance, checkpoint progress, remaining route, obstacle sensors, arena boundaries, current action and velocity-to-goal alignment.

The simulation now advances 10 Godot physics ticks per Python decision instead of 4, so training runs about 2.5x faster while keeping the same 30 Hz physics step internally.

The reward now strongly prioritizes checkpoint/finish progress and penalizes time, death and dangerous obstacle proximity. Whole-route progress is also included so a temporary sideways detour around an obstacle is not treated as completely wrong.

Because the observation size changed, old v2.1/v2.2/v2.3 PPO model files are not compatible. Start v2.4 training from scratch.
