from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import BaseCallback, CheckpointCallback
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize

from godot_env import GodotDroneEnv


class CurriculumStatsCallback(BaseCallback):
    """Human-readable curriculum/learning statistics for every PPO rollout."""

    def __init__(self, verbose: int = 0):
        super().__init__(verbose)
        self.rollout_number = 0
        self.batch_episodes: list[dict[str, Any]] = []
        self.all_episodes: list[dict[str, Any]] = []
        self.episode_counter = 0

    @staticmethod
    def _record_from_info(info: dict[str, Any], fallback_reward: float = 0.0, fallback_length: int = 0) -> dict[str, Any]:
        episode = info.get("episode", {}) or {}
        stats = info.get("episode_stats", {}) or {}
        return {
            "episode": int(stats.get("episode", 0)),
            "level": int(stats.get("level", info.get("level", 1))),
            "reward": float(episode.get("r", fallback_reward)),
            "lifetime_steps": int(stats.get("lifetime_steps", episode.get("l", fallback_length))),
            "lifetime_seconds": float(stats.get("lifetime_seconds", 0.0)),
            "checkpoints": int(stats.get("checkpoints", 0)),
            "efficiency": float(stats.get("efficiency", 0.0)),
            "travel_distance": float(stats.get("travel_distance", 0.0)),
            "success": bool(stats.get("success", info.get("success", False))),
            "reason": str(stats.get("reason", "unknown")),
            "level_success_rate": float(stats.get("level_success_rate", info.get("level_success_rate", 0.0))),
            "level_mean_checkpoints": float(stats.get("level_mean_checkpoints", info.get("level_mean_checkpoints", 0.0))),
            "level_mean_efficiency": float(stats.get("level_mean_efficiency", info.get("level_mean_efficiency", 0.0))),
            "level_requirements_met": bool(stats.get("level_requirements_met", info.get("level_requirements_met", False))),
            "level_window": int(stats.get("level_window", info.get("level_window", 0))),
            "promoted": bool(stats.get("promoted", False)),
        }

    def _on_step(self) -> bool:
        infos = self.locals.get("infos", [])
        dones = self.locals.get("dones", [])
        rewards = self.locals.get("rewards", [])
        for index, (info, done) in enumerate(zip(infos, dones)):
            if not done:
                continue
            fallback_reward = float(rewards[index]) if index < len(rewards) else 0.0
            record = self._record_from_info(info, fallback_reward, int(info.get("step", 0)))
            record["ppo_iteration"] = self.rollout_number + 1
            self.episode_counter += 1
            if record["episode"] <= 0:
                record["episode"] = self.episode_counter
            self.batch_episodes.append(record)
            self.all_episodes.append(record)

        # Stop immediately after the Godot curriculum reaches level 10 at 95%.
        for info in infos:
            if info.get("training_complete", False):
                self._print_final_report()
                return False
        return True

    @staticmethod
    def _fmt_time(seconds: float) -> str:
        if seconds <= 0.0:
            return "n/a"
        return f"{seconds:.1f}s"

    @staticmethod
    def _mean(records: list[dict[str, Any]], key: str) -> float:
        if not records:
            return 0.0
        return float(np.mean([float(r[key]) for r in records]))

    def _print_rollout_report(self) -> None:
        if not self.batch_episodes:
            print(f"\n[AI] PPO ITERATION {self.rollout_number} | {self.num_timesteps:,} steps | no completed episodes in this batch")
            return

        records = self.batch_episodes
        latest = records[-1]
        level = latest["level"]
        rate = latest["level_success_rate"]
        window = latest["level_window"]
        mean_reward = self._mean(records, "reward")
        mean_lifetime = self._mean(records, "lifetime_steps")
        mean_time = self._mean(records, "lifetime_seconds")
        mean_checkpoints = self._mean(records, "checkpoints")
        mean_efficiency = self._mean(records, "efficiency")
        success_rate = 100.0 * float(np.mean([1.0 if r["success"] else 0.0 for r in records]))

        best_reward = max(records, key=lambda r: r["reward"])
        best_lifetime = max(records, key=lambda r: r["lifetime_steps"])
        best_checkpoints = max(records, key=lambda r: r["checkpoints"])
        successful = [r for r in records if r["success"]]
        fastest_success = min(successful, key=lambda r: r["lifetime_steps"]) if successful else None
        best_efficiency = max(records, key=lambda r: r["efficiency"])

        print("\n" + "=" * 72)
        print(f"AI TRAINING | PPO ITERATION {self.rollout_number} | {self.num_timesteps:,} TOTAL STEPS")
        print("=" * 72)
        mean_level_checkpoints = latest["level_mean_checkpoints"]
        mean_level_efficiency = latest["level_mean_efficiency"]
        level_obstacles = round(5 + (level - 1) * 55 / 9) if level <= 10 else 60
        print(f"LEVEL: {level}/10   | obstacles: {level_obstacles}")
        if window:
            print(f"LEVEL WINDOW: {window}/20 completed episodes")
            print(f"  success             : {rate * 100:.1f}% / 95% required")
            print(f"  mean checkpoints    : {mean_level_checkpoints:.2f} / 5 / 4.00 required")
            print(f"  mean path efficiency: {mean_level_efficiency * 100.0:.1f}% / 65% required")
        else:
            print("LEVEL WINDOW: 0/20 | building the level evaluation window")

        print("\nMEAN — episodes completed in this PPO batch")
        print(f"  reward/score       : {mean_reward:+.2f}")
        print(f"  lifetime            : {mean_lifetime:.1f} RL steps ({self._fmt_time(mean_time)})")
        print(f"  checkpoints         : {mean_checkpoints:.2f} / 5")
        print(f"  path efficiency     : {mean_efficiency * 100.0:.1f}%")
        print(f"  success rate        : {success_rate:.1f}%")

        print("\nBEST — inside this PPO batch")
        print(f"  best reward         : {best_reward['reward']:+.2f}  (episode {best_reward['episode']}, PPO iter {best_reward['ppo_iteration']})")
        print(f"  longest lifetime    : {best_lifetime['lifetime_steps']} steps  ({self._fmt_time(best_lifetime['lifetime_seconds'])})  (episode {best_lifetime['episode']}, PPO iter {best_lifetime['ppo_iteration']})")
        print(f"  most checkpoints    : {best_checkpoints['checkpoints']} / 5  (episode {best_checkpoints['episode']}, PPO iter {best_checkpoints['ppo_iteration']})")
        if fastest_success:
            print(f"  fastest finish      : {fastest_success['lifetime_steps']} steps  ({self._fmt_time(fastest_success['lifetime_seconds'])})  (episode {fastest_success['episode']}, PPO iter {fastest_success['ppo_iteration']})")
        else:
            print("  fastest finish      : none yet")
        print(f"  best path efficiency: {best_efficiency['efficiency'] * 100.0:.1f}% (episode {best_efficiency['episode']}, PPO iter {best_efficiency['ppo_iteration']})")

        print("\nTOP 5 EPISODES — this PPO batch, ranked by reward")
        ranked = sorted(records, key=lambda r: r["reward"], reverse=True)[:5]
        for rank, record in enumerate(ranked, start=1):
            status = "FINISH" if record["success"] else record["reason"].upper()
            print(
                f"  #{rank} ep {record['episode']:>5} | iter {record['ppo_iteration']:>3} | reward {record['reward']:+8.2f} | "
                f"life {record['lifetime_steps']:>4} | CP {record['checkpoints']}/5 | {status}"
            )

        if any(r["promoted"] for r in records):
            promoted = [r for r in records if r["promoted"]][-1]
            print(
                f"\n🚀 LEVEL UP: Level {promoted['level']} cleared — "
                f"success {promoted['level_success_rate'] * 100:.0f}% + "
                f"checkpoints {promoted['level_mean_checkpoints']:.2f}/5 + "
                f"efficiency {promoted['level_mean_efficiency'] * 100:.0f}% -> next level."
            )
        elif latest["level_requirements_met"]:
            print("\n🟢 LEVEL REQUIREMENTS MET — promotion will happen on the next reset.")
        elif mean_checkpoints > 0.0 or success_rate > 0.0:
            print("\n🟡 GOAL LEARNING DETECTED — checkpoints/finishes are appearing.")
        else:
            print("\n🔴 GOAL NOT REACHED IN THIS BATCH — keep training and watch the trend.")
        print("=" * 72)
        self.batch_episodes.clear()

    def _on_rollout_end(self) -> None:
        self.rollout_number += 1
        self._print_rollout_report()

    def _print_final_report(self) -> None:
        print("\n" + "#" * 72)
        print("TRAINING COMPLETE — ALL 10 LEVELS CLEARED AT >=95% SUCCESS")
        print("#" * 72)
        if not self.all_episodes:
            return
        top = sorted(self.all_episodes, key=lambda r: r["reward"], reverse=True)[:5]
        print("TOP 5 EPISODES OF THE FULL TRAINING RUN")
        for rank, record in enumerate(top, start=1):
            print(
                f"  #{rank} ep {record['episode']:>5} | level {record['level']} | "
                f"iter {record['ppo_iteration']:>3} | reward {record['reward']:+8.2f} | lifetime {record['lifetime_steps']:>4} | "
                f"CP {record['checkpoints']}/5 | {'FINISH' if record['success'] else record['reason'].upper()}"
            )
        print("#" * 72)


ROOT = Path(__file__).resolve().parent
MODEL_DIR = ROOT / "models"
LOG_DIR = ROOT / "logs"
MODEL_DIR.mkdir(exist_ok=True)
LOG_DIR.mkdir(exist_ok=True)


def main() -> None:
    print("Connects to Godot at 127.0.0.1:5000")
    print("Start the Godot project first, then run this script.")
    print("Curriculum: 10 levels, 20-episode rolling window. Level-up requires >=95% success, >=4.0/5 mean checkpoints, and >=65% mean path efficiency. Obstacles progress from 5 to 60.")
    print("Learning aids: goal-relative actions, 8-action lookahead features, short-term action memory, and reward normalization.")

    def make_env() -> Monitor:
        return Monitor(GodotDroneEnv(max_steps=900), filename=str(LOG_DIR / "training"))

    env = DummyVecEnv([make_env])
    env = VecNormalize(env, norm_obs=False, norm_reward=True, clip_reward=10.0, gamma=0.995)
    checkpoint = CheckpointCallback(
        save_freq=25_000,
        save_path=str(MODEL_DIR),
        name_prefix="drone_ppo",
    )
    stats = CurriculumStatsCallback()

    model = PPO(
        "MlpPolicy",
        env,
        learning_rate=1.5e-4,
        n_steps=2048,
        batch_size=256,
        n_epochs=10,
        gamma=0.995,
        gae_lambda=0.95,
        ent_coef=0.0005,
        max_grad_norm=0.5,
        verbose=1,
        tensorboard_log=str(LOG_DIR / "tensorboard"),
        device="auto",
    )

    model.learn(total_timesteps=2_000_000, callback=[checkpoint, stats], progress_bar=False)
    model.save(MODEL_DIR / "drone_ppo_final")
    env.save(str(MODEL_DIR / "vecnormalize.pkl"))
    env.close()
    print("Training finished. Model saved to ai/models/drone_ppo_final.zip")
    print("Normalization statistics saved to ai/models/vecnormalize.pkl")


if __name__ == "__main__":
    main()
