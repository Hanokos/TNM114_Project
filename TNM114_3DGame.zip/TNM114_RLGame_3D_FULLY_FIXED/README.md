# TNM114 3D RL Drone - Fully Fixed

This version fixes the nested Drone class material errors.

Controls:
- W/S = forward/back
- A/D = left/right
- Q/E = down/up
- R = reset

RL interface:
- reset_environment()
- step(action)
- get_observation()

Actions:
0 = forward
1 = left
2 = right
3 = up
4 = down

The project contains a simple 3D drone, obstacles, checkpoints, a final goal, rewards, and a basic RL-ready interface. Python is not connected yet.
