extends Node3D

# TNM114 3D reinforcement-learning drone prototype
#
# Human controls:
#   W/S = forward/back
#   A/D = left/right
#   Q/E = down/up
#   R   = reset
#
# RL interface:
#   reset_environment()
#   step(action)
#   get_observation()
#
# Actions:
#   0 = forward
#   1 = left
#   2 = right
#   3 = up
#   4 = down

const WORLD_SIZE := Vector3(34.0, 14.0, 80.0)
const START_POSITION := Vector3(0.0, 3.0, 5.0)
const CHECKPOINTS := [
    Vector3(0.0, 5.0, 25.0),
    Vector3(-7.0, 7.0, 48.0),
    Vector3(7.0, 4.0, 66.0)
]
const GOAL_POSITION := Vector3(0.0, 5.0, 78.0)

var drone: Drone
var obstacles: Array[Dictionary] = []
var checkpoint_index := 0
var episode_done := false
var reward := 0.0
var last_distance := 0.0
var info_label: Label3D
var camera: Camera3D

func _ready() -> void:
    _create_environment()
    _create_drone()
    _create_camera()
    _create_ui()
    reset_environment()

func _process(_delta: float) -> void:
    if drone and camera:
        camera.position = drone.position + Vector3(0, 10, 15)
        camera.look_at(drone.position + Vector3(0, 0, 8), Vector3.UP)

func _physics_process(_delta: float) -> void:
    if Input.is_action_just_pressed("reset_game"):
        reset_environment()

    if drone:
        _keep_drone_in_bounds()
        _check_obstacles()

func _create_environment() -> void:
    # Lighting
    var world_environment := WorldEnvironment.new()
    var env := Environment.new()
    env.background_mode = Environment.BG_COLOR
    env.background_color = Color("#101827")
    env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    env.ambient_light_color = Color("#8fa0b8")
    env.ambient_light_energy = 0.7
    world_environment.environment = env
    add_child(world_environment)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-55, -25, 0)
    sun.light_energy = 1.2
    add_child(sun)

    # Ground / course floor
    var ground := MeshInstance3D.new()
    var ground_mesh := BoxMesh.new()
    ground_mesh.size = Vector3(WORLD_SIZE.x, 0.4, WORLD_SIZE.z)
    ground.mesh = ground_mesh
    ground.position = Vector3(0, -0.4, WORLD_SIZE.z / 2.0)
    ground.material_override = _material(Color("#253348"))
    add_child(ground)

    # Side walls to make the course visually obvious
    _create_box(Vector3(-WORLD_SIZE.x / 2.0, 3.0, WORLD_SIZE.z / 2.0), Vector3(0.5, 6.0, WORLD_SIZE.z), Color("#34445b"))
    _create_box(Vector3(WORLD_SIZE.x / 2.0, 3.0, WORLD_SIZE.z / 2.0), Vector3(0.5, 6.0, WORLD_SIZE.z), Color("#34445b"))

    # Obstacles
    _add_obstacle(Vector3(0, 3.0, 16), Vector3(10, 5, 4))
    _add_obstacle(Vector3(7, 6.0, 34), Vector3(5, 6, 5))
    _add_obstacle(Vector3(-7, 3.0, 43), Vector3(5, 5, 7))
    _add_obstacle(Vector3(2, 8.0, 55), Vector3(10, 3, 4))
    _add_obstacle(Vector3(-6, 4.0, 65), Vector3(6, 6, 5))

    # Checkpoints
    for i in range(CHECKPOINTS.size()):
        _create_checkpoint(CHECKPOINTS[i], i + 1)

    # Goal
    _create_goal(GOAL_POSITION)

func _create_drone() -> void:
    drone = Drone.new()
    drone.name = "Drone"
    add_child(drone)
    drone.position = START_POSITION

func _create_camera() -> void:
    camera = Camera3D.new()
    camera.current = true
    camera.fov = 70
    add_child(camera)

func _create_ui() -> void:
    info_label = Label3D.new()
    info_label.font_size = 32
    info_label.modulate = Color.WHITE
    info_label.position = Vector3(-15, 12, 5)
    info_label.no_depth_test = true
    add_child(info_label)


func _create_box(pos: Vector3, size: Vector3, color: Color) -> void:
    var body := StaticBody3D.new()
    body.position = pos

    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    mesh.material_override = _material(color)
    body.add_child(mesh)

    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    collision.shape = shape
    body.add_child(collision)

    add_child(body)

func _add_obstacle(pos: Vector3, size: Vector3) -> void:
    var body := StaticBody3D.new()
    body.position = pos

    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    mesh.material_override = _material(Color("#d14f4f"))
    body.add_child(mesh)

    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = size
    collision.shape = shape
    body.add_child(collision)

    add_child(body)
    obstacles.append({"position": pos, "size": size})

func _create_checkpoint(pos: Vector3, number: int) -> void:
    var ring := MeshInstance3D.new()
    var torus := TorusMesh.new()
    torus.inner_radius = 2.0
    torus.outer_radius = 2.25
    ring.mesh = torus
    ring.position = pos
    ring.rotation_degrees = Vector3(90, 0, 0)
    ring.material_override = _material(Color("#e2bd45"))
    add_child(ring)

    var label := Label3D.new()
    label.text = "CHECKPOINT " + str(number)
    label.font_size = 24
    label.position = pos + Vector3(-3, 2.5, 0)
    label.no_depth_test = true
    add_child(label)

func _create_goal(pos: Vector3) -> void:
    var ring := MeshInstance3D.new()
    var torus := TorusMesh.new()
    torus.inner_radius = 2.5
    torus.outer_radius = 2.9
    ring.mesh = torus
    ring.position = pos
    ring.rotation_degrees = Vector3(90, 0, 0)
    ring.material_override = _material(Color("#54d68a"))
    add_child(ring)

    var label := Label3D.new()
    label.text = "FINAL GOAL"
    label.font_size = 30
    label.position = pos + Vector3(-3, 3.5, 0)
    label.no_depth_test = true
    add_child(label)

func _material(color: Color) -> StandardMaterial3D:
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    return mat

func _keep_drone_in_bounds() -> void:
    drone.position.x = clamp(drone.position.x, -WORLD_SIZE.x / 2.0 + 1.0, WORLD_SIZE.x / 2.0 - 1.0)
    drone.position.y = clamp(drone.position.y, 1.0, WORLD_SIZE.y - 1.0)
    drone.position.z = clamp(drone.position.z, 1.0, WORLD_SIZE.z - 1.0)

func _check_obstacles() -> void:
    for obstacle in obstacles:
        var p: Vector3 = obstacle["position"]
        var s: Vector3 = obstacle["size"] / 2.0
        if abs(drone.position.x - p.x) < s.x + 0.8 \
        and abs(drone.position.y - p.y) < s.y + 0.8 \
        and abs(drone.position.z - p.z) < s.z + 0.8:
            reward = -10.0
            episode_done = true
            drone.stop()
            info_label.text = "CRASH! Reward: -10 | Press R to reset"

    _check_progress()

func _check_progress() -> void:
    if episode_done:
        return

    if checkpoint_index < CHECKPOINTS.size():
        var target: Vector3 = CHECKPOINTS[checkpoint_index]
        if drone.position.distance_to(target) < 3.0:
            reward = 10.0
            checkpoint_index += 1
            if checkpoint_index == CHECKPOINTS.size():
                info_label.text = "All checkpoints reached! Find the FINAL GOAL!"
            else:
                info_label.text = "Checkpoint reached! Next: " + str(checkpoint_index + 1)

    elif drone.position.distance_to(GOAL_POSITION) < 3.5:
        reward = 100.0
        episode_done = true
        drone.stop()
        info_label.text = "YOU WIN! Reward: +100 | Press R to reset"

func reset_environment() -> Array:
    episode_done = false
    reward = 0.0
    checkpoint_index = 0
    drone.position = START_POSITION
    drone.velocity = Vector3.ZERO
    drone.manual_control = true
    last_distance = drone.position.distance_to(CHECKPOINTS[0])
    info_label.text = "TNM114 3D DRONE | WASD move | Q/E up/down | R reset"
    return get_observation()

# First RL-compatible step interface.
func step(action: int) -> Dictionary:
    if episode_done:
        return {
            "observation": get_observation(),
            "reward": reward,
            "done": true
        }

    drone.manual_control = false
    drone.rl_action = action
    drone.apply_rl_action()

    var target: Vector3 = CHECKPOINTS[min(checkpoint_index, CHECKPOINTS.size() - 1)]
    var new_distance := drone.position.distance_to(target)
    var shaped_reward := (last_distance - new_distance) * 0.05 - 0.01
    last_distance = new_distance
    reward = shaped_reward

    return {
        "observation": get_observation(),
        "reward": reward,
        "done": episode_done
    }

func get_observation() -> Array:
    var target: Vector3 = CHECKPOINTS[min(checkpoint_index, CHECKPOINTS.size() - 1)]
    var to_target := target - drone.position
    return [
        drone.position.x / (WORLD_SIZE.x / 2.0),
        drone.position.y / WORLD_SIZE.y,
        drone.position.z / WORLD_SIZE.z,
        to_target.x / WORLD_SIZE.x,
        to_target.y / WORLD_SIZE.y,
        to_target.z / WORLD_SIZE.z,
        float(checkpoint_index) / float(CHECKPOINTS.size())
    ]

class Drone extends CharacterBody3D:
    var speed := 9.0
    var manual_control := true
    var rl_action := 0

    func _ready() -> void:
        # Main body
        var mesh := MeshInstance3D.new()
        var box := BoxMesh.new()
        box.size = Vector3(1.5, 0.45, 1.0)
        mesh.mesh = box
        mesh.material_override = _drone_material(Color("#4fa3ff"))
        add_child(mesh)

        # Four simple rotors
        var rotor_positions := [
            Vector3(-0.75, 0.05, -0.55),
            Vector3(0.75, 0.05, -0.55),
            Vector3(-0.75, 0.05, 0.55),
            Vector3(0.75, 0.05, 0.55)
        ]

        for rotor_pos in rotor_positions:
            var rotor := MeshInstance3D.new()
            var cylinder := CylinderMesh.new()
            cylinder.top_radius = 0.22
            cylinder.bottom_radius = 0.22
            cylinder.height = 0.08
            rotor.mesh = cylinder
            rotor.position = rotor_pos
            rotor.material_override = _drone_material(Color("#222b3a"))
            add_child(rotor)

        var light := OmniLight3D.new()
        light.light_color = Color("#4fa3ff")
        light.light_energy = 1.5
        light.omni_range = 5
        add_child(light)

        var collision := CollisionShape3D.new()
        var shape := BoxShape3D.new()
        shape.size = Vector3(1.6, 0.6, 1.2)
        collision.shape = shape
        add_child(collision)

    func _drone_material(color: Color) -> StandardMaterial3D:
        var mat := StandardMaterial3D.new()
        mat.albedo_color = color
        return mat

    func _physics_process(_delta: float) -> void:
        if manual_control:
            var direction := Vector3.ZERO

            if Input.is_key_pressed(KEY_W):
                direction.z -= 1
            if Input.is_key_pressed(KEY_S):
                direction.z += 1
            if Input.is_key_pressed(KEY_A):
                direction.x -= 1
            if Input.is_key_pressed(KEY_D):
                direction.x += 1
            if Input.is_key_pressed(KEY_Q):
                direction.y -= 1
            if Input.is_key_pressed(KEY_E):
                direction.y += 1

            if direction.length() > 1:
                direction = direction.normalized()

            velocity = direction * speed
            move_and_slide()

    func apply_rl_action() -> void:
        var direction := Vector3.ZERO

        match rl_action:
            0:
                direction = Vector3(0, 0, -1)
            1:
                direction = Vector3(-1, 0, 0)
            2:
                direction = Vector3(1, 0, 0)
            3:
                direction = Vector3(0, 1, 0)
            4:
                direction = Vector3(0, -1, 0)

        velocity = direction * speed
        move_and_slide()

    func stop() -> void:
        velocity = Vector3.ZERO
        manual_control = true
