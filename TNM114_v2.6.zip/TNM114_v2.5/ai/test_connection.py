from godot_env import GodotDroneEnv


def main() -> None:
    env = GodotDroneEnv(max_steps=50)
    try:
        obs, info = env.reset()
        print("Connected to Godot! TCP hello received.")
        print("Episode:", info["episode"], "Run:", info["run"])
        print("Level:", info["level"], "Obstacles:", info["obstacles"])
        print("Observation shape:", obs.shape)
        print("Observation length:", len(obs))

        for action in range(5):
            obs, reward, terminated, truncated, info = env.step(action)
            print(
                f"action={action} reward={reward:.3f} "
                f"terminated={terminated} truncated={truncated} "
                f"death={info['death']} success={info['success']} "
                f"level={info['level']}"
            )
            if terminated or truncated:
                print("Episode ended. Resetting Godot for a new random run...")
                obs, info = env.reset()
                print("New episode:", info["episode"], "Run:", info["run"], "Level:", info["level"])
    finally:
        env.close()


if __name__ == "__main__":
    main()
