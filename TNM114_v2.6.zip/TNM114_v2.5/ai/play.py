from pathlib import Path

from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv, VecNormalize

from godot_env import GodotDroneEnv


ROOT = Path(__file__).resolve().parent
MODEL = ROOT / "models" / "drone_ppo_final.zip"
VEC_STATS = ROOT / "models" / "vecnormalize.pkl"


def main() -> None:
    if not MODEL.exists():
        raise FileNotFoundError(
            f"No trained model found at {MODEL}. Run train.py first."
        )

    raw_env = DummyVecEnv([lambda: GodotDroneEnv(max_steps=900)])
    if VEC_STATS.exists():
        env = VecNormalize.load(str(VEC_STATS), raw_env)
        env.training = False
        env.norm_reward = False
    else:
        env = raw_env
    model = PPO.load(MODEL, env=env)
    obs = env.reset()

    try:
        while True:
            action, _ = model.predict(obs, deterministic=True)
            obs, rewards, dones, infos = env.step(action)
            if dones[0]:
                obs = env.reset()
    except KeyboardInterrupt:
        print("Stopped.")
    finally:
        env.close()


if __name__ == "__main__":
    main()
