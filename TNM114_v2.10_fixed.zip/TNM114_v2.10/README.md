# TNM114 v2.10 — Drone Reinforcement Learning

This version expands the TRON visual style beyond the arena floor. The outer world now has a distinct dark-violet/cyan/magenta palette, a distant neon skyline, rotating holographic hoops, floating signal beacons and pulsing lights. These elements are decorative only and do not participate in physics or RL observations.


This version adds a **10-level curriculum** and much clearer training statistics.

The drone still flies in random 3D airspace, but the learning objective is now:

**reach the current checkpoint quickly → avoid obstacles → reach the next checkpoint → finish.**

Survival by itself is no longer the main objective.

## 10-level curriculum

- Level 1 starts with **5 obstacles** and Level 10 reaches **60 obstacles**.
- The progression is gradual: **5, 11, 17, 23, 29, 36, 42, 48, 54, 60** obstacles.
- Obstacles are kept separated and the checkpoint-to-checkpoint route remains realistically solvable even at the harder levels.
- Each episode gets a new random airspace at the current level.
- A level uses the **latest 20 completed episodes** as its rolling evaluation window.
- The next level starts only when all three curriculum gates are met:
  - **>= 70% successful finishes**
  - **>= 4.0 / 5.0 mean checkpoints**
  - **>= 65% mean path efficiency**
- After Level 10 satisfies the same three gates, training is reported as complete.

A successful episode means reaching all 5 checkpoints and the finish.

## Reward idea

The reward is designed around the actual objective:

- **Progress toward the active checkpoint:** positive reward
- **Moving away from the active checkpoint:** negative reward
- **Time:** small continuous penalty, encouraging faster routes
- **Checkpoint:** +100
- **Finish:** +500
- **Collision / leaving the allowed airspace / time limit:** -180
- **Nearby obstacle:** small warning penalty

The observation explicitly includes the direction and distance to the current goal, the current checkpoint number, the curriculum level, obstacle sensors, velocity and boundary information.

## Training output

Every PPO rollout is printed as a human-readable **PPO iteration/batch** report:

- mean reward/score in that batch
- mean lifetime in RL steps and seconds
- mean checkpoints reached
- mean success rate
- rolling level success rate, mean checkpoints and mean path efficiency
- best reward in the batch
- longest lifetime in the batch
- most checkpoints in the batch
- fastest successful finish in the batch
- top 5 episodes in that batch
- current level and all three curriculum gates

When all 10 levels are cleared, the terminal prints the **top 5 episodes of the complete training run**.

## What is a step?

One RL step is one decision from the Python policy. Godot holds that action for 10 physics ticks at 30 Hz, so one RL step is approximately 0.333 seconds of simulated flight.

Therefore `ep_len_mean = 397` means the average completed episode lasted about 397 AI decisions, not that 397 seconds passed.

## Scene structure

- Main
  - WorldEnvironment
  - Sun
  - GroundVisual
  - RandomAirObstacles
  - Drone
    - CollisionShape3D
  - Checkpoints
    - Checkpoint1 ... Checkpoint5
  - Finish
  - Camera3D
  - UI
    - InfoLabel

Checkpoint and finish rings are visual-only. They have no physics collision.
Only generated red obstacles and leaving the allowed airspace can destroy the drone.

## Controls

- W/A/S/D: horizontal movement
- Q/E: down/up
- R: generate a new random airspace

## Python setup

Open a Visual Studio terminal in `ai/` and run:

```powershell
.\setup.bat
```

The batch file intentionally follows the same direct `python -m pip install ...` style as a manual terminal setup. It does not use a PowerShell installer or `ensurepip`.

You do not need to activate the virtual environment.

## Run

1. Open `project.godot` in Godot 4.
2. Press **Play**.
3. In the `ai` terminal run:

```powershell
.\test.bat
```

4. If the protocol test passes:

```powershell
.\train.bat
```

5. To run the saved policy later:

```powershell
.\play.bat
```

Models are saved in `ai/models/` and TensorBoard logs are saved in `ai/logs/`.


## v2.4 learning improvements

The training setup is designed to learn actual goal-directed obstacle avoidance instead of only surviving:

- Some obstacles are deliberately placed close to the direct checkpoint route, so the fastest route sometimes requires a left/right/up/down detour.
- The remaining obstacles are random and increase with the curriculum level.
- The observation now has denser 3D obstacle sensing: 16 horizontal directions plus up/down.
- Obstacle danger is penalized smoothly before collision, so the policy gets an early signal that an object is dangerous.
- Progress toward the active checkpoint is rewarded more strongly.
- Every RL step has a time cost, so wandering is expensive.
- A successful finish gets an additional path-efficiency bonus based on route distance versus distance actually flown.
- Training statistics now show path efficiency as well as reward, lifetime, checkpoints, and success rate.

This means the desired behavior is: **reach the next checkpoint, avoid dangerous obstacles, avoid unnecessary detours, and finish quickly without dying.**


## v2.4 control and speed improvements

v2.4 is intentionally more goal-directed. The drone's actions are defined relative to the active checkpoint/finish, so action 0 always means "fly toward the goal" and the neighboring actions are controlled left/right/up/down detours. The observation has 72 values and explicitly encodes the drone position, goal position/direction/distance, checkpoint progress, remaining route, obstacle sensing and arena boundaries.

Godot now advances 10 internal 30 Hz physics ticks per RL decision (about 0.333 simulated seconds), instead of 4. This makes training substantially faster while keeping the physics resolution unchanged.

Reward is weighted toward reaching checkpoints/finish, making progress, avoiding dangerous obstacles and minimizing time. Temporary sideways movement can still be useful because whole-route progress is also rewarded.

Start v2.4 training from scratch; old model files are incompatible because the observation size changed.


## v2.8 TRON visual upgrade

This release polishes the visuals without changing the learning task:

- The drone now uses a custom procedural quadcopter model with a carbon-style chassis, reinforced arms, motor housings, camera lens, front/rear status LEDs, landing skids, and four counter-rotating animated propellers.
- The arena has a subtle measurement grid, luminous boundary rails, and corner beacons to make the flight volume easier to read.
- Collidable obstacles use dark metallic shells and bright red emissive hazard trim so collision hazards are immediately recognizable. Crates, energy mines, and columns retain their existing silhouettes, with cleaner TRON-style edge lighting.
- The floor outside the arena now extends into a dark neon grid with cyan/magenta circuit traces, replacing the plain blue empty space. The added scenery is visual-only and has no collision.
- Checkpoint rings use layered gold/cyan accents and the finish label uses a green highlight.

**RL compatibility:** visual-only changes. The observation vector, action mapping, reward calculation, obstacle positions/radii, collision shapes, level thresholds, Python environment, and PPO training implementation are unchanged. Existing models remain compatible as long as they use the same 72-observation and 8-action interface.
