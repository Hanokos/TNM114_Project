class_name Drone
extends CharacterBody3D

signal killed

@export var speed: float = 11.0
var manual_control: bool = true
var rl_action: int = 0
var alive: bool = true

var _visual_root: Node3D
var _rotor_spinners: Array[Node3D] = []
var _rotor_spin_directions: Array[float] = [1.0, -1.0, -1.0, 1.0]
var _tilt_roll: float = 0.0
var _tilt_pitch: float = 0.0
const MAX_VISUAL_ROLL: float = 0.34
const MAX_VISUAL_PITCH: float = 0.22
const TILT_RESPONSE: float = 4.5

func _ready() -> void:
	collision_layer = 1
	collision_mask = 1
	setup_visuals()

func setup_visuals() -> void:
	# Keep the physics collision shape untouched. All upgraded geometry lives in
	# a dedicated visual root, so visual polish never changes the RL environment.
	var previous: Node = get_node_or_null("VisualRoot")
	if previous != null:
		remove_child(previous)
		previous.free()

	_visual_root = Node3D.new()
	_visual_root.name = "VisualRoot"
	add_child(_visual_root)
	_rotor_spinners.clear()

	var carbon := _visual_material(Color("172438"), 0.72, 0.28)
	var frame_material := _visual_material(Color("344a63"), 0.62, 0.3)
	var shell_material := _visual_material(Color("2c86c9"), 0.48, 0.24)
	var shell_highlight := _visual_material(Color("69d6ff"), 0.32, 0.22, Color("27aaff"))
	var black := _visual_material(Color("101722"), 0.35, 0.3)
	var prop_material := _visual_material(Color("d8e5f2"), 0.28, 0.24)
	var red_light := _visual_material(Color("ff526b"), 0.15, 0.2, Color("ff2148"))
	var blue_light := _visual_material(Color("b9f2ff"), 0.12, 0.18, Color("36caff"))

	# Main carbon-fibre chassis and raised battery shell.
	var chassis := BoxMesh.new()
	chassis.size = Vector3(1.18, 0.28, 0.82)
	_add_mesh(_visual_root, "CarbonChassis", chassis, Vector3(0.0, 0.0, 0.0), carbon)

	var shell := BoxMesh.new()
	shell.size = Vector3(0.82, 0.22, 0.58)
	_add_mesh(_visual_root, "ArmoredTopShell", shell, Vector3(0.0, 0.19, 0.035), shell_material)

	var top_panel := BoxMesh.new()
	top_panel.size = Vector3(0.52, 0.035, 0.34)
	_add_mesh(_visual_root, "TopPanel", top_panel, Vector3(0.0, 0.32, 0.035), frame_material)

	# Bright nose and camera lens face the drone's forward direction (-Z).
	var nose := BoxMesh.new()
	nose.size = Vector3(0.34, 0.1, 0.18)
	_add_mesh(_visual_root, "NoseGuard", nose, Vector3(0.0, 0.08, -0.46), frame_material)

	var camera_lens := SphereMesh.new()
	camera_lens.radius = 0.105
	camera_lens.height = 0.21
	_add_mesh(_visual_root, "FrontCameraLens", camera_lens, Vector3(0.0, 0.055, -0.56), blue_light)

	var front_bar := BoxMesh.new()
	front_bar.size = Vector3(0.42, 0.045, 0.06)
	_add_mesh(_visual_root, "FrontLEDBar", front_bar, Vector3(0.0, 0.22, -0.34), blue_light)

	var rear_led_left := SphereMesh.new()
	rear_led_left.radius = 0.07
	rear_led_left.height = 0.14
	_add_mesh(_visual_root, "RearLEDLeft", rear_led_left, Vector3(-0.43, 0.13, 0.34), red_light)
	var rear_led_right := SphereMesh.new()
	rear_led_right.radius = 0.07
	rear_led_right.height = 0.14
	_add_mesh(_visual_root, "RearLEDRight", rear_led_right, Vector3(0.43, 0.13, 0.34), red_light)

	# Four reinforced arms, motors, hubs and real rotating two-blade propellers.
	var rotor_positions: Array[Vector3] = [
		Vector3(-0.78, 0.11, -0.55),
		Vector3(0.78, 0.11, -0.55),
		Vector3(-0.78, 0.11, 0.55),
		Vector3(0.78, 0.11, 0.55)
	]
	for index: int in range(rotor_positions.size()):
		var rotor_position: Vector3 = rotor_positions[index]
		var arm_direction: Vector3 = rotor_position - Vector3(0.0, 0.04, 0.0)
		var arm := CylinderMesh.new()
		arm.top_radius = 0.075
		arm.bottom_radius = 0.095
		arm.height = arm_direction.length()
		var arm_instance := _add_mesh(_visual_root, "Arm_%d" % index, arm, arm_direction * 0.5 + Vector3(0.0, 0.04, 0.0), frame_material)
		arm_instance.basis = Basis(Quaternion(Vector3.UP, arm_direction.normalized()))

		var motor := CylinderMesh.new()
		motor.top_radius = 0.19
		motor.bottom_radius = 0.21
		motor.height = 0.16
		_add_mesh(_visual_root, "Motor_%d" % index, motor, rotor_position, black)

		var motor_cap := CylinderMesh.new()
		motor_cap.top_radius = 0.12
		motor_cap.bottom_radius = 0.12
		motor_cap.height = 0.045
		_add_mesh(_visual_root, "MotorCap_%d" % index, motor_cap, rotor_position + Vector3(0.0, 0.095, 0.0), shell_highlight)

		var spinner := Node3D.new()
		spinner.name = "PropellerSpinner_%d" % index
		spinner.position = rotor_position + Vector3(0.0, 0.16, 0.0)
		_visual_root.add_child(spinner)
		_rotor_spinners.append(spinner)

		var blade := BoxMesh.new()
		blade.size = Vector3(1.0, 0.035, 0.115)
		_add_mesh(spinner, "PropellerBlades", blade, Vector3.ZERO, prop_material)

		# Coloured tips make the spin visible even when the propellers are fast.
		var tip_left := BoxMesh.new()
		tip_left.size = Vector3(0.16, 0.04, 0.12)
		_add_mesh(spinner, "BladeTipLeft", tip_left, Vector3(-0.41, 0.004, 0.0), shell_highlight)
		var tip_right := BoxMesh.new()
		tip_right.size = Vector3(0.16, 0.04, 0.12)
		_add_mesh(spinner, "BladeTipRight", tip_right, Vector3(0.41, 0.004, 0.0), shell_highlight)

		var hub := SphereMesh.new()
		hub.radius = 0.09
		hub.height = 0.18
		_add_mesh(spinner, "PropellerHub", hub, Vector3(0.0, 0.025, 0.0), black)

	# Lightweight landing skids and their supports.
	for x_side: float in [-0.38, 0.38]:
		for z_side: float in [-0.28, 0.28]:
			var support := CylinderMesh.new()
			support.top_radius = 0.035
			support.bottom_radius = 0.045
			support.height = 0.28
			_add_mesh(_visual_root, "LandingSupport_%s_%s" % [str(x_side), str(z_side)], support, Vector3(x_side, -0.22, z_side), black)
		var skid := BoxMesh.new()
		skid.size = Vector3(0.08, 0.055, 0.72)
		_add_mesh(_visual_root, "LandingSkid_%s" % str(x_side), skid, Vector3(x_side, -0.36, 0.0), frame_material)

func _process(delta: float) -> void:
	# Counter-rotating propellers. The animation remains active during playback.
	var spin_speed: float = 42.0 if alive else 0.0
	for index: int in range(_rotor_spinners.size()):
		_rotor_spinners[index].rotate_y(delta * spin_speed * _rotor_spin_directions[index])

	# Smooth flight attitude: bank into lateral movement and pitch into forward/reverse
	# motion. Exponential smoothing prevents snapping when the chosen action changes.
	if is_instance_valid(_visual_root):
		var safe_speed: float = maxf(speed, 0.1)
		var target_roll: float = clampf(-velocity.x / safe_speed, -1.0, 1.0) * MAX_VISUAL_ROLL if alive else 0.0
		var target_pitch: float = clampf(velocity.z / safe_speed, -1.0, 1.0) * MAX_VISUAL_PITCH if alive else 0.0
		var blend: float = 1.0 - exp(-TILT_RESPONSE * delta)
		_tilt_roll = lerpf(_tilt_roll, target_roll, blend)
		_tilt_pitch = lerpf(_tilt_pitch, target_pitch, blend)
		_visual_root.rotation = Vector3(_tilt_pitch, 0.0, _tilt_roll)

func _add_mesh(parent: Node3D, node_name: String, mesh_resource: Mesh, local_position: Vector3, material: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh_resource
	instance.position = local_position
	instance.material_override = material
	parent.add_child(instance)
	return instance

func _visual_material(color: Color, metallic: float = 0.0, roughness: float = 0.4, emission_color: Color = Color.TRANSPARENT) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = color
	material.metallic = metallic
	material.roughness = roughness
	if emission_color != Color.TRANSPARENT:
		material.emission_enabled = true
		material.emission = emission_color
		material.emission_energy_multiplier = 2.2
	return material

func reset_for_run(new_position: Vector3) -> void:
	global_position = new_position
	velocity = Vector3.ZERO
	manual_control = true
	rl_action = 0
	alive = true
	_tilt_roll = 0.0
	_tilt_pitch = 0.0
	if is_instance_valid(_visual_root):
		_visual_root.rotation = Vector3.ZERO
	set_physics_process(true)

func _physics_process(_delta: float) -> void:
	if not manual_control or not alive:
		return

	var direction: Vector3 = Vector3.ZERO
	if Input.is_key_pressed(KEY_W):
		direction.z -= 1.0
	if Input.is_key_pressed(KEY_S):
		direction.z += 1.0
	if Input.is_key_pressed(KEY_A):
		direction.x -= 1.0
	if Input.is_key_pressed(KEY_D):
		direction.x += 1.0
	if Input.is_key_pressed(KEY_Q):
		direction.y -= 1.0
	if Input.is_key_pressed(KEY_E):
		direction.y += 1.0

	if direction.length_squared() > 1.0:
		direction = direction.normalized()
	velocity = direction * speed
	move_and_slide()

func action_direction(action: int) -> Vector3:
	match action:
		0: return Vector3(0.0, 0.0, -1.0)
		1: return Vector3(-1.0, 0.0, -1.0).normalized()
		2: return Vector3(1.0, 0.0, -1.0).normalized()
		3: return Vector3(0.0, 1.0, 0.0)
		4: return Vector3(0.0, -1.0, 0.0)
		5: return Vector3(0.0, 0.0, 1.0)
		6: return Vector3(-1.0, 0.0, 0.0)
		7: return Vector3(1.0, 0.0, 0.0)
		_: return Vector3.ZERO

func apply_rl_action(action: int) -> void:
	if not alive:
		return
	rl_action = action
	var direction := action_direction(action)
	velocity = direction * speed
	move_and_slide()

func _goal_relative_direction(action: int, target_position: Vector3) -> Vector3:
	var to_target: Vector3 = target_position - global_position
	if to_target.length_squared() < 0.0001:
		return Vector3.ZERO

	var forward: Vector3 = to_target.normalized()
	var horizontal_forward := Vector3(forward.x, 0.0, forward.z)
	if horizontal_forward.length_squared() < 0.01:
		horizontal_forward = Vector3.FORWARD
	horizontal_forward = horizontal_forward.normalized()
	var left := Vector3.UP.cross(horizontal_forward).normalized()
	match action:
		0: return forward
		1: return (forward + left * 0.85).normalized()
		2: return (forward - left * 0.85).normalized()
		3: return (forward + Vector3.UP * 0.85).normalized()
		4: return (forward - Vector3.UP * 0.85).normalized()
		5: return left
		6: return -left
		7: return -forward
		_: return forward

func simulate_rl_tick(action: int, delta_seconds: float, target_position: Vector3 = Vector3.ZERO) -> KinematicCollision3D:
	if not alive:
		return null
	manual_control = false
	rl_action = action
	var direction := _goal_relative_direction(action, target_position)
	velocity = direction * speed
	var collision: KinematicCollision3D = move_and_collide(direction * speed * delta_seconds)
	return collision

func stop() -> void:
	velocity = Vector3.ZERO
	manual_control = false
	alive = false
	set_physics_process(false)
