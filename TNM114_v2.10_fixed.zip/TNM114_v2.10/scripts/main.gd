extends Node3D

const ARENA_HALF_X: float = 30.0
const ARENA_MIN_Z: float = 2.0
const ARENA_MAX_Z: float = 62.0
const MIN_ALTITUDE: float = 3.0
const MAX_ALTITUDE: float = 22.0
const CHECKPOINT_COUNT: int = 5
const CHECKPOINT_RADIUS: float = 3.0
const FINISH_RADIUS: float = 3.0
const MIN_CHECKPOINT_DISTANCE: float = 10.0
const MAX_LEVEL: int = 10
const LEVEL_SUCCESS_WINDOW: int = 100
const LEVEL_SUCCESS_RATE_REQUIRED: float = 0.70
const LEVEL_MEAN_CHECKPOINTS_REQUIRED: float = 4.0
const LEVEL_MEAN_EFFICIENCY_REQUIRED: float = 0.65
const OBSTACLE_COUNT_BASE: int = 5
const OBSTACLE_MAX_COUNT: int = 60
const ROUTE_CLEARANCE: float = 4.5
const OBSTACLE_MIN_DISTANCE_FROM_DRONE_START: float = 9.0
const OBSTACLE_MIN_DISTANCE_FROM_CHECKPOINT: float = 6.0
const OBSTACLE_MIN_RADIUS: float = 1.0
const OBSTACLE_MAX_RADIUS: float = 3.0
const DRONE_SAFE_RADIUS: float = 0.8
const REWARD_CHECKPOINT: float = 150.0
const REWARD_FINISH: float = 800.0
const REWARD_DEATH: float = -300.0
const REWARD_TIME: float = -0.04
const REWARD_PROGRESS_SCALE: float = 1.6
const REWARD_OBSTACLE_SCALE: float = 0.18
const REWARD_OBSTACLE_DANGER_SCALE: float = 1.8
const REWARD_EFFICIENCY_BONUS: float = 350.0
const OBSTACLE_WARNING_DISTANCE: float = 6.0
const OBSTACLE_DANGER_DISTANCE: float = 2.5
const ROUTE_CHALLENGE_MIN: int = 1
const ROUTE_CHALLENGE_MAX: int = 12
const RL_ACTION_HOLD_TICKS: int = 8
const RL_SIM_DT: float = 1.0 / 30.0
const RL_PORT: int = 5000
const RL_MAX_MESSAGE_BYTES: int = 65536
# --- NEW: training-effectiveness constants ---
const REWARD_STUCK: float = -300.0   # same as death, so "hover safely" is never a good strategy
const STUCK_TICK_LIMIT: int = 1200   # physics ticks (about 40 s simulated) without making route progress
# --- NEW: short decisions near obstacles ---
const OBSTACLE_INTERRUPT_DISTANCE: float = 6.0   # clearance (m) below which the agent decides more often
const NEAR_OBSTACLE_HOLD_TICKS: int = 2          # ticks per decision while close to an obstacle
const REPLAY_PROBABILITY: float = 0.15
# --- NEW: watch mode (real-time playback) ---
const WATCH_EVERY_EPISODES: int = 0  # every 20th episode is played in real time (0 = off)
const WATCH_SPEED: float = 1.0         # 1.0 = real time, 0.5 = slow motion, 2.0 = 2x
# --- NEW: turbo training ---
const DISABLE_RENDER_WHILE_TRAINING: bool = true   # no drawing while training; press W to see it
const TURBO_FRAME_BUDGET_USEC: int = 8000          # max time spent answering Python per frame
const TURBO_IDLE_USEC: int = 2000                  # stop waiting if Python is silent this long

@onready var world_environment: WorldEnvironment = $WorldEnvironment
@onready var ground_visual: MeshInstance3D = $GroundVisual
@onready var obstacle_root: Node3D = $RandomAirObstacles
@onready var drone: Drone = $Drone
@onready var checkpoint_root: Node3D = $Checkpoints
@onready var finish_root: Node3D = $Finish
@onready var camera: Camera3D = $Camera3D
@onready var info_label: Label3D = $UI/InfoLabel

var checkpoints: Array[Vector3] = []
var checkpoint_nodes: Array[Node3D] = []
var obstacles: Array[Dictionary] = []
var goal_position: Vector3 = Vector3.ZERO
var checkpoint_index: int = 0
var last_checkpoint_reached: int = 0
var episode_done: bool = false
var reward: float = 0.0
var last_distance: float = 0.0
var run_number: int = 0
var rng := RandomNumberGenerator.new()
var start_position: Vector3 = Vector3(0.0, 10.0, 4.0)
var rl_server: TCPServer = TCPServer.new()
var rl_peer: StreamPeerTCP = null
var rl_receive_buffer: String = ""
var training_level: int = 1
var level_results: Array[bool] = []
var level_checkpoint_results: Array[float] = []
var level_efficiency_results: Array[float] = []
var total_episodes: int = 0
var total_successes: int = 0
var episode_step_count: int = 0
var episode_sim_time: float = 0.0
var episode_start_level: int = 1
var episode_started: bool = false
var episode_checkpoint_count: int = 0
var episode_best_progress: float = 0.0
var episode_travel_distance: float = 0.0
var episode_last_position: Vector3 = Vector3.ZERO
var episode_route_distance: float = 0.0
var training_complete: bool = false
var last_episode_stats: Dictionary = {}
var action_memory: Array[float] = []
# --- NEW ---
var episode_map_level: int = 1
var ticks_since_progress: int = 0
var best_remaining_route: float = 0.0
var manual_watch: bool = false          # toggled with the W key
var auto_watch_episode: bool = false    # set at reset by WATCH_EVERY_EPISODES
var watch_active: bool = false
var rl_messages_handled: int = 0
# Visual-only TRON animation state. These nodes/materials never affect RL physics.
var _environment_time: float = 0.0
var _tron_scanline_nodes: Array[Node3D] = []
var _hazard_pulse_materials: Array[StandardMaterial3D] = []
var _rotating_hazard_rings: Array[MeshInstance3D] = []
var _outer_rotating_nodes: Array[Node3D] = []
var _outer_pulse_materials: Array[StandardMaterial3D] = []
var _outer_float_nodes: Array[Node3D] = []
var _outer_float_base_y: Array[float] = []

func _ready() -> void:
	Engine.max_fps = 0   # no frame cap
	DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
	_setup_world()
	_setup_drone_collision()
	_cache_checkpoint_nodes()
	reset_environment()
	_start_rl_server()

func _process(delta: float) -> void:
	_animate_tron_environment(delta)
	_poll_rl_connection()
	_turbo_poll()
	if is_instance_valid(drone):
		camera.global_position = drone.global_position + Vector3(0.0, 13.0, 17.0)
		camera.look_at(drone.global_position + Vector3(0.0, 0.0, 5.0), Vector3.UP)

func _apply_watch_state() -> void:
	watch_active = manual_watch or auto_watch_episode
	if DISABLE_RENDER_WHILE_TRAINING:
		# Draw only when watching, or when no Python client is connected yet.
		RenderingServer.render_loop_enabled = watch_active or rl_peer == null

func _turbo_poll() -> void:
	# Keep answering Python's requests inside this frame instead of one per frame.
	# Without this, training speed is capped by the frame rate.
	if watch_active or rl_peer == null:
		return
	var start: int = Time.get_ticks_usec()
	var last_count: int = rl_messages_handled
	var last_activity: int = start
	while rl_peer != null and not watch_active:
		var now: int = Time.get_ticks_usec()
		if now - start > TURBO_FRAME_BUDGET_USEC:
			break
		_poll_rl_connection()
		if rl_messages_handled != last_count:
			last_count = rl_messages_handled
			last_activity = now
		elif now - last_activity > TURBO_IDLE_USEC:
			break
		else:
			OS.delay_usec(50)

func _start_rl_server() -> void:
	var error: Error = rl_server.listen(RL_PORT, "127.0.0.1")
	if error == OK:
		info_label.text = "READY | Python RL can connect on 127.0.0.1:%d" % RL_PORT
	else:
		push_error("Could not start RL server on port %d: %s" % [RL_PORT, error_string(error)])

func _poll_rl_connection() -> void:
	if rl_peer == null and rl_server.is_connection_available():
		rl_peer = rl_server.take_connection()
		rl_peer.set_no_delay(true)
		rl_receive_buffer = ""
		rl_peer.poll()
		print("[RL] Python client connected.")
		_send_rl_message({"type": "hello", "protocol": 1})

	if rl_peer == null:
		return

	# StreamPeerTCP needs poll() to refresh its connection state and buffered data.
	rl_peer.poll()
	if rl_peer.get_status() != StreamPeerTCP.STATUS_CONNECTED:
		print("[RL] Python client disconnected.")
		rl_peer = null
		rl_receive_buffer = ""
		_apply_watch_state()
		return

	var available: int = rl_peer.get_available_bytes()
	if available <= 0:
		return
	if available > RL_MAX_MESSAGE_BYTES:
		rl_peer = null
		rl_receive_buffer = ""
		return

	rl_receive_buffer += rl_peer.get_utf8_string(available)
	while true:
		var newline_index: int = rl_receive_buffer.find("\n")
		if newline_index < 0:
			break
		var line: String = rl_receive_buffer.substr(0, newline_index).strip_edges()
		rl_receive_buffer = rl_receive_buffer.substr(newline_index + 1)
		if line.is_empty():
			continue
		var message: Variant = JSON.parse_string(line)
		if message is Dictionary:
			_handle_rl_message(message as Dictionary)

func _handle_rl_message(message: Dictionary) -> void:
	rl_messages_handled += 1
	var command: String = str(message.get("cmd", ""))
	match command:
		"reset":
			var observation: Array = reset_environment()
			print("[RL] Reset complete. Run=", run_number)
			_send_rl_message({"type": "reset", "observation": observation, "run": run_number, "level": training_level, "obstacles": _current_obstacle_count(), "level_success_rate": _level_success_rate(), "level_mean_checkpoints": _level_mean_checkpoints(), "level_mean_efficiency": _level_mean_efficiency(), "level_requirements_met": _level_requirements_met(), "level_window": level_results.size(), "training_complete": training_complete})
		"step":
			var action: int = int(message.get("action", 0))
			var result: Dictionary = await step(action)
			_send_rl_message({
				"type": "step",
				"observation": result["observation"],
				"reward": result["reward"],
				"done": result["done"],
				"checkpoint_reached": last_checkpoint_reached,
				"episode_stats": result.get("episode_stats", {}),
				"level": result.get("level", training_level),
				"level_success_rate": result.get("level_success_rate", _level_success_rate()),
				"level_mean_checkpoints": result.get("level_mean_checkpoints", _level_mean_checkpoints()),
				"level_mean_efficiency": result.get("level_mean_efficiency", _level_mean_efficiency()),
				"level_requirements_met": result.get("level_requirements_met", _level_requirements_met()),
				"level_window": result.get("level_window", level_results.size()),
				"training_complete": result.get("training_complete", training_complete)
			})
		"timeout":
			_handle_rl_timeout()
		"ping":
			_send_rl_message({"type": "pong"})
		_:
			_send_rl_message({"type": "error", "message": "Unknown command: %s" % command})

func _handle_rl_timeout() -> void:
	if not episode_done:
		reward = REWARD_DEATH
		episode_done = true
		drone.stop()
		_record_episode_result(false, "time_limit")
	_send_rl_message({
		"type": "timeout",
		"observation": get_observation(),
		"reward": reward,
		"done": true,
		"episode_stats": last_episode_stats.duplicate(true),
		"level": training_level,
		"level_success_rate": _level_success_rate(),
		"level_mean_checkpoints": _level_mean_checkpoints(),
		"level_mean_efficiency": _level_mean_efficiency(),
		"level_requirements_met": _level_requirements_met(),
		"level_window": level_results.size(),
		"training_complete": training_complete
	})

func _send_rl_message(message: Dictionary) -> void:
	if rl_peer == null:
		return
	rl_peer.poll()
	if rl_peer.get_status() != StreamPeerTCP.STATUS_CONNECTED:
		rl_peer = null
		rl_receive_buffer = ""
		return
	# Base64 keeps every TCP response strictly ASCII, avoiding partial UTF-8
	# decoding errors when Python reads a TCP stream.
	var json_payload: String = JSON.stringify(message)
	var encoded: String = Marshalls.raw_to_base64(json_payload.to_utf8_buffer())
	# IMPORTANT: put_utf8_string() writes a binary length prefix. Python expects
	# a newline-delimited ASCII stream, so use put_data() instead.
	var wire_bytes: PackedByteArray = (encoded + "\n").to_utf8_buffer()
	var error: Error = rl_peer.put_data(wire_bytes)
	if error != OK:
		print("[RL] Failed to send response: ", error_string(error))
	else:
		rl_peer.poll()

func _physics_process(_delta: float) -> void:
	if episode_done:
		return
	# In watch mode step() waits between ticks; the RL step does all the checks itself.
	if watch_active and not drone.manual_control:
		return
	_check_physics_collisions()
	if episode_done:
		return
	_check_environment_rules()
	if episode_done:
		return
	_check_checkpoint_distance()
	if episode_done:
		return
	_check_finish_distance()

func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey:
		var key_event: InputEventKey = event
		if key_event.pressed and not key_event.echo and key_event.keycode == KEY_R:
			reset_environment()
		elif key_event.pressed and not key_event.echo and key_event.keycode == KEY_W:
			manual_watch = not manual_watch
			_apply_watch_state()
			print("[RL] Watch mode: ", "ON (real time)" if manual_watch else "OFF (full speed)")

func _setup_world() -> void:
	var environment := Environment.new()
	environment.background_mode = Environment.BG_COLOR
	environment.background_color = Color("08111f")
	environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	environment.ambient_light_color = Color("8fa8c4")
	environment.ambient_light_energy = 0.95
	environment.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	environment.glow_enabled = true
	environment.glow_intensity = 0.45
	world_environment.environment = environment

	var ground_mesh := BoxMesh.new()
	ground_mesh.size = Vector3(ARENA_HALF_X * 2.0 + 10.0, 0.4, ARENA_MAX_Z - ARENA_MIN_Z + 10.0)
	ground_visual.mesh = ground_mesh
	ground_visual.position = Vector3(0.0, 0.0, (ARENA_MIN_Z + ARENA_MAX_Z) / 2.0)
	ground_visual.material_override = _material(Color("101d30"))
	_create_arena_visuals()

func _animate_tron_environment(delta: float) -> void:
	_environment_time += delta
	for index: int in range(_tron_scanline_nodes.size()):
		var scanline: Node3D = _tron_scanline_nodes[index]
		scanline.position.z += delta * (2.0 + float(index) * 0.55)
		if scanline.position.z > ARENA_MAX_Z + 3.0:
			scanline.position.z = ARENA_MIN_Z - 3.0 - float(index) * 5.0
	for index: int in range(_hazard_pulse_materials.size()):
		var material: StandardMaterial3D = _hazard_pulse_materials[index]
		var pulse: float = 0.5 + 0.5 * sin(_environment_time * 2.2 + float(index) * 0.73)
		material.emission_energy_multiplier = 1.7 + pulse * 1.8
	for index: int in range(_rotating_hazard_rings.size()):
		var ring: MeshInstance3D = _rotating_hazard_rings[index]
		ring.rotate_y(delta * (0.45 + float(index % 3) * 0.22) * (1.0 if index % 2 == 0 else -1.0))
	# The world outside the flight arena has its own motion language: distant towers,
	# rotating holographic fins, drifting beacons and purple/cyan energy pulses.
	for index: int in range(_outer_rotating_nodes.size()):
		var rotating_node: Node3D = _outer_rotating_nodes[index]
		rotating_node.rotate_y(delta * (0.18 + float(index % 4) * 0.07) * (1.0 if index % 2 == 0 else -1.0))
	for index: int in range(_outer_pulse_materials.size()):
		var pulse_material: StandardMaterial3D = _outer_pulse_materials[index]
		var pulse: float = 0.5 + 0.5 * sin(_environment_time * (1.1 + float(index % 3) * 0.35) + float(index) * 0.91)
		pulse_material.emission_energy_multiplier = 0.9 + pulse * 2.6
	for index: int in range(_outer_float_nodes.size()):
		var floating_node: Node3D = _outer_float_nodes[index]
		floating_node.position.y = _outer_float_base_y[index] + sin(_environment_time * 0.65 + float(index) * 0.8) * 0.7

func _setup_drone_collision() -> void:
	var collision: CollisionShape3D = $Drone/CollisionShape3D
	var shape := BoxShape3D.new()
	shape.size = Vector3(1.6, 0.6, 1.2)
	collision.shape = shape
	drone.collision_layer = 1
	drone.collision_mask = 1

func _cache_checkpoint_nodes() -> void:
	checkpoint_nodes.clear()
	for child: Node in checkpoint_root.get_children():
		if child is Node3D:
			checkpoint_nodes.append(child as Node3D)
	checkpoint_nodes.sort_custom(_sort_checkpoint_nodes)

func _sort_checkpoint_nodes(a: Node3D, b: Node3D) -> bool:
	return a.name.naturalnocasecmp_to(b.name) < 0

func reset_environment() -> Array:
	# A reset without a terminal event is treated as a failed episode (for example
	# a Gymnasium time-limit truncation). This keeps the 70% curriculum rate honest.
	if episode_started and not episode_done:
		_record_episode_result(false, "timeout_or_external_reset")

	run_number += 1
	rng.randomize()

	# NEW: sometimes replay an easier level so the policy does not forget it.
	# Replay episodes do NOT count toward promotion statistics.
	episode_map_level = training_level
	if training_level > 1 and rng.randf() < REPLAY_PROBABILITY:
		episode_map_level = rng.randi_range(1, training_level - 1)
	ticks_since_progress = 0

	auto_watch_episode = WATCH_EVERY_EPISODES > 0 and total_episodes > 0 and total_episodes % WATCH_EVERY_EPISODES == 0
	_apply_watch_state()
	if auto_watch_episode:
		print("[RL] WATCH MODE: episode %d plays in real time." % (total_episodes + 1))

	_clear_runtime_obstacles()
	checkpoints.clear()
	obstacles.clear()
	goal_position = Vector3.ZERO
	checkpoint_index = 0
	last_checkpoint_reached = 0
	episode_done = false
	reward = 0.0

	episode_step_count = 0
	episode_sim_time = 0.0
	episode_start_level = training_level
	episode_checkpoint_count = 0
	episode_best_progress = 0.0
	episode_travel_distance = 0.0
	episode_last_position = start_position
	episode_route_distance = 0.0
	action_memory.clear()
	for _i: int in range(8):
		action_memory.append(0.0)
	episode_started = true
	# Build the route first, then place obstacles around it. This guarantees that
	# every level always has a valid path and prevents a level transition from
	# generating an impossible/invalid checkpoint layout.
	_generate_checkpoints()
	_generate_finish()
	_generate_random_airspace()

	drone.reset_for_run(start_position)
	episode_route_distance = _remaining_route_distance()
	best_remaining_route = episode_route_distance
	last_distance = drone.global_position.distance_to(checkpoints[0])
	_update_checkpoint_visibility()
	info_label.text = "LVL %d/10 | RUN %d | CHECKPOINT 1 / 5 | %d OBSTACLES" % [episode_map_level, run_number, _current_obstacle_count()]
	return get_observation()

func _clear_runtime_obstacles() -> void:
	_hazard_pulse_materials.clear()
	_rotating_hazard_rings.clear()
	for child: Node in obstacle_root.get_children():
		child.queue_free()

func _obstacle_count_for_level(level: int) -> int:
	# Smooth curriculum from 5 obstacles on level 1 to exactly 60 on level 10.
	# Rounded progression: 5, 11, 17, 23, 29, 36, 42, 48, 54, 60.
	var count: int = roundi(float(OBSTACLE_COUNT_BASE) + float(level - 1) * float(OBSTACLE_MAX_COUNT - OBSTACLE_COUNT_BASE) / float(MAX_LEVEL - 1))
	return clampi(count, OBSTACLE_COUNT_BASE, OBSTACLE_MAX_COUNT)

func _current_obstacle_count() -> int:
	return _obstacle_count_for_level(episode_map_level)

func _generate_random_airspace() -> void:
	var target_count: int = _current_obstacle_count()
	var challenge_count: int = clampi(int(ceil(float(target_count) * 0.25)), ROUTE_CHALLENGE_MIN, ROUTE_CHALLENGE_MAX)

	# First place a few deliberate route challenges. These obstacles are close to
	# the straight-line route, so the fastest path is no longer always a straight
	# line. They never sit directly on a checkpoint and there is always room to
	# pass around them in the large arena.
	var challenge_attempts: int = 0
	while _count_route_challenges() < challenge_count and challenge_attempts < challenge_count * 100:
		challenge_attempts += 1
		var segment_index: int = rng.randi_range(0, CHECKPOINT_COUNT)
		var a: Vector3 = start_position if segment_index == 0 else checkpoints[segment_index - 1]
		var b: Vector3 = checkpoints[segment_index] if segment_index < CHECKPOINT_COUNT else goal_position
		var segment: Vector3 = b - a
		if segment.length_squared() < 25.0:
			continue

		var t: float = rng.randf_range(0.32, 0.68)
		var center: Vector3 = a.lerp(b, t)
		var forward: Vector3 = segment.normalized()
		var side: Vector3 = forward.cross(Vector3.UP)
		if side.length_squared() < 0.01:
			side = Vector3.RIGHT
		else:
			side = side.normalized()

		# Keep the obstacle near, but not exactly on, the direct route. The agent
		# must notice it and learn to go left/right or above/below it.
		var offset: float = rng.randf_range(-1.4, 1.4)
		var obstacle_position: Vector3 = center + side * offset
		obstacle_position.y = clampf(obstacle_position.y, MIN_ALTITUDE + 1.2, MAX_ALTITUDE - 1.2)
		var radius: float = rng.randf_range(1.0, 1.8)

		if obstacle_position.distance_to(start_position) < OBSTACLE_MIN_DISTANCE_FROM_DRONE_START:
			continue
		if not _point_is_clear_of_checkpoints_with_margin(obstacle_position, radius + OBSTACLE_MIN_DISTANCE_FROM_CHECKPOINT):
			continue
		if not _obstacle_is_separated(obstacle_position, radius, 2.5):
			continue
		_create_random_obstacle(obstacle_position, radius, rng.randi_range(0, 2), true)

	# Fill the remaining slots with ordinary random obstacles. These make the
	# environment progressively richer without turning it into an impossible wall.
	var attempts: int = 0
	while obstacles.size() < target_count and attempts < target_count * 250:
		attempts += 1
		var obstacle_position := Vector3(
			rng.randf_range(-ARENA_HALF_X + 3.0, ARENA_HALF_X - 3.0),
			rng.randf_range(MIN_ALTITUDE + 1.0, MAX_ALTITUDE - 1.0),
			rng.randf_range(ARENA_MIN_Z + 5.0, ARENA_MAX_Z - 4.0)
		)
		if obstacle_position.distance_to(start_position) < OBSTACLE_MIN_DISTANCE_FROM_DRONE_START:
			continue
		var radius: float = rng.randf_range(OBSTACLE_MIN_RADIUS, minf(OBSTACLE_MAX_RADIUS, 2.2))
		if not _point_is_clear_of_checkpoints_with_margin(obstacle_position, radius + OBSTACLE_MIN_DISTANCE_FROM_CHECKPOINT):
			continue
		if not _obstacle_is_separated(obstacle_position, radius, 2.0):
			continue
		_create_random_obstacle(obstacle_position, radius, rng.randi_range(0, 2), false)

func _count_route_challenges() -> int:
	var count: int = 0
	for obstacle: Dictionary in obstacles:
		if bool(obstacle.get("route_challenge", false)):
			count += 1
	return count

func _point_is_clear_of_checkpoints_with_margin(candidate: Vector3, margin: float) -> bool:
	for point: Vector3 in checkpoints:
		if candidate.distance_to(point) < margin:
			return false
	if goal_position != Vector3.ZERO and candidate.distance_to(goal_position) < margin:
		return false
	return true

func _obstacle_is_separated(candidate: Vector3, radius: float, extra_gap: float) -> bool:
	for obstacle: Dictionary in obstacles:
		var other_position: Vector3 = obstacle["position"] as Vector3
		var other_radius: float = float(obstacle["radius"])
		if candidate.distance_to(other_position) < radius + other_radius + extra_gap:
			return false
	return true

func _create_random_obstacle(obstacle_position: Vector3, radius: float, obstacle_type: int, route_challenge: bool = false) -> void:
	# Keep the same collision shapes/radii used by the RL sensors. The added
	# geometry is decorative only, so visuals cannot silently change training.
	var body := StaticBody3D.new()
	body.name = "Obstacle_%02d" % obstacles.size()
	body.position = obstacle_position
	body.collision_layer = 1
	body.collision_mask = 1
	body.add_to_group("drone_kill")

	var collision := CollisionShape3D.new()
	var base_mesh: MeshInstance3D
	# All collidable hazards read as RED at a glance. Route-challenge hazards use a
	# hotter red, while the dark metallic shell and tiny cyan details keep the TRON look.
	var accent_color: Color = Color("ff315b") if route_challenge else Color("ff123f")
	var body_material := _material(Color("101522"), Color("26000b"))
	var accent_material := _material(accent_color, accent_color)
	accent_material.emission_energy_multiplier = 2.8
	_hazard_pulse_materials.append(accent_material)
	var secondary_material := _material(Color("48dfff"), Color("168cff"))

	match obstacle_type:
		0:
			# Industrial floating crate with bright hazard rails and a front panel.
			var box := BoxMesh.new()
			box.size = Vector3(radius * 1.7, radius * 1.5, radius * 1.7)
			base_mesh = _add_world_mesh(body, "CrateBody", box, Vector3.ZERO, body_material)
			var box_shape := BoxShape3D.new()
			box_shape.size = box.size
			collision.shape = box_shape
			for x_side: float in [-1.0, 1.0]:
				for z_side: float in [-1.0, 1.0]:
					var rail := BoxMesh.new()
					rail.size = Vector3(0.085, box.size.y * 1.04, 0.085)
					_add_world_mesh(body, "CornerRail", rail, Vector3(x_side * box.size.x * 0.43, 0.0, z_side * box.size.z * 0.43), accent_material)
			var front_panel := BoxMesh.new()
			front_panel.size = Vector3(box.size.x * 0.54, box.size.y * 0.42, 0.045)
			_add_world_mesh(body, "FrontHazardPanel", front_panel, Vector3(0.0, 0.0, -box.size.z * 0.51), accent_material)
			var top_mark := BoxMesh.new()
			top_mark.size = Vector3(box.size.x * 0.6, 0.045, 0.12)
			_add_world_mesh(body, "TopWarningStripe", top_mark, Vector3(0.0, box.size.y * 0.51, 0.0), accent_material)
			# Layered armor plates, slanted hazard chevrons and recessed side panels.
			var front_armor := BoxMesh.new()
			front_armor.size = Vector3(box.size.x * 0.68, box.size.y * 0.60, 0.055)
			_add_world_mesh(body, "FrontArmorPlate", front_armor, Vector3(0.0, 0.0, -box.size.z * 0.535), body_material)
			for stripe_index: int in range(3):
				var chevron := BoxMesh.new()
				chevron.size = Vector3(0.09, box.size.y * 0.32, 0.065)
				var chevron_instance := _add_world_mesh(body, "HazardChevron_%d" % stripe_index, chevron, Vector3((float(stripe_index) - 1.0) * box.size.x * 0.18, 0.0, -box.size.z * 0.57), accent_material)
				chevron_instance.rotation_degrees.z = -22.0 if stripe_index % 2 == 0 else 22.0
			for x_side: float in [-1.0, 1.0]:
				var side_plate := BoxMesh.new()
				side_plate.size = Vector3(0.055, box.size.y * 0.48, box.size.z * 0.48)
				_add_world_mesh(body, "SideArmorPlate", side_plate, Vector3(x_side * box.size.x * 0.515, 0.0, 0.0), body_material)
				var side_signal := BoxMesh.new()
				side_signal.size = Vector3(0.065, 0.07, box.size.z * 0.26)
				_add_world_mesh(body, "SideHazardSignal", side_signal, Vector3(x_side * box.size.x * 0.55, box.size.y * 0.22, 0.0), accent_material)
			# Thin luminous perimeter rails make the crate silhouette readable at a distance.
			for y_side: float in [-1.0, 1.0]:
				for z_side: float in [-1.0, 1.0]:
					var x_rail := BoxMesh.new()
					x_rail.size = Vector3(box.size.x * 0.92, 0.055, 0.055)
					_add_world_mesh(body, "CratePerimeterX", x_rail, Vector3(0.0, y_side * box.size.y * 0.47, z_side * box.size.z * 0.47), accent_material)
				for x_side: float in [-1.0, 1.0]:
					var z_rail := BoxMesh.new()
					z_rail.size = Vector3(0.055, 0.055, box.size.z * 0.92)
					_add_world_mesh(body, "CratePerimeterZ", z_rail, Vector3(x_side * box.size.x * 0.47, y_side * box.size.y * 0.47, 0.0), accent_material)
		1:
			# Reactive energy mine: dark core with two luminous protective hoops.
			var sphere := SphereMesh.new()
			sphere.radius = radius
			sphere.height = radius * 2.0
			base_mesh = _add_world_mesh(body, "MineCore", sphere, Vector3.ZERO, body_material)
			var sphere_shape := SphereShape3D.new()
			sphere_shape.radius = radius
			collision.shape = sphere_shape
			for ring_index: int in range(3):
				var ring_mesh := TorusMesh.new()
				ring_mesh.inner_radius = radius * (0.66 + float(ring_index) * 0.055)
				ring_mesh.outer_radius = radius * (0.74 + float(ring_index) * 0.055)
				var ring_rotation := Vector3(90.0, 0.0, 0.0) if ring_index == 0 else (Vector3(0.0, 0.0, 0.0) if ring_index == 1 else Vector3(0.0, 0.0, 90.0))
				var energy_hoop := _add_world_mesh(body, "EnergyHoop_%d" % ring_index, ring_mesh, Vector3.ZERO, accent_material, ring_rotation)
				_rotating_hazard_rings.append(energy_hoop)
			var core := SphereMesh.new()
			core.radius = radius * 0.28
			core.height = radius * 0.56
			_add_world_mesh(body, "EnergyCore", core, Vector3.ZERO, accent_material)
		_:
			# Hazard column with luminous bands and a capped industrial top.
			var cylinder := CylinderMesh.new()
			cylinder.top_radius = radius
			cylinder.bottom_radius = radius
			cylinder.height = radius * 2.0
			base_mesh = _add_world_mesh(body, "HazardColumn", cylinder, Vector3.ZERO, body_material)
			var cylinder_shape := CylinderShape3D.new()
			cylinder_shape.radius = radius
			cylinder_shape.height = cylinder.height
			collision.shape = cylinder_shape
			for y_side: float in [-0.55, 0.0, 0.55]:
				var band := TorusMesh.new()
				band.inner_radius = radius * 0.84
				band.outer_radius = radius * 0.98
				var column_band := _add_world_mesh(body, "ColumnBand", band, Vector3(0.0, y_side * radius, 0.0), accent_material, Vector3(90.0, 0.0, 0.0))
				_rotating_hazard_rings.append(column_band)
			# Reinforced vertical ribs give the hazard column a machined industrial shell.
			for rib_index: int in range(8):
				var angle: float = TAU * float(rib_index) / 8.0
				var rib := BoxMesh.new()
				rib.size = Vector3(0.09, cylinder.height * 0.72, 0.09)
				var rib_instance := _add_world_mesh(body, "ColumnRib_%d" % rib_index, rib, Vector3(cos(angle) * radius * 0.91, 0.0, sin(angle) * radius * 0.91), accent_material)
				rib_instance.rotation_degrees.y = -rad_to_deg(angle)
			var cap := CylinderMesh.new()
			cap.top_radius = radius * 0.72
			cap.bottom_radius = radius * 0.72
			cap.height = 0.12
			_add_world_mesh(body, "ColumnCap", cap, Vector3(0.0, radius * 0.91, 0.0), accent_material)

	body.add_child(collision)
	obstacle_root.add_child(body)
	obstacles.append({"position": obstacle_position, "radius": radius, "body": body, "route_challenge": route_challenge})

func _add_world_mesh(parent: Node3D, node_name: String, mesh_resource: Mesh, local_position: Vector3, material: Material, local_rotation_degrees: Vector3 = Vector3.ZERO) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	instance.name = node_name
	instance.mesh = mesh_resource
	instance.position = local_position
	instance.rotation_degrees = local_rotation_degrees
	instance.material_override = material
	parent.add_child(instance)
	return instance

func _create_arena_visuals() -> void:
	_outer_rotating_nodes.clear()
	_outer_pulse_materials.clear()
	_outer_float_nodes.clear()
	_outer_float_base_y.clear()
	var old_decor: Node = get_node_or_null("ArenaDecor")
	if old_decor != null:
		remove_child(old_decor)
		old_decor.free()
	var decor := Node3D.new()
	decor.name = "ArenaDecor"
	add_child(decor)

	# Extend the world beneath the arena so the view never falls into a flat blue void.
	# This is visual-only: it has no collision and does not affect the RL state or physics.
	var outer_floor := MeshInstance3D.new()
	outer_floor.name = "TRON_OuterFloor"
	var outer_floor_mesh := BoxMesh.new()
	outer_floor_mesh.size = Vector3(400.0, 0.3, 400.0)
	outer_floor.mesh = outer_floor_mesh
	outer_floor.position = Vector3(0.0, -0.35, 32.0)
	outer_floor.material_override = _material(Color("050914"), Color("050b1c"))
	decor.add_child(outer_floor)

	var grid_material := _material(Color("102a42"), Color("09263f"))
	var bright_grid_material := _material(Color("174e70"), Color("0d4569"))
	var border_material := _material(Color("39c9f2"), Color("1598ce"))
	var post_material := _material(Color("101a2b"), Color("0b1427"))
	var post_light_material := _material(Color("80ecff"), Color("31c9ff"))
	var outer_grid_material := _material(Color("10233b"), Color("0b2948"))
	var circuit_cyan := _material(Color("167da2"), Color("087da8"))
	var circuit_magenta := _material(Color("742b9a"), Color("6419a0"))
	# Wide-area neon grid is deliberately subtle; the raised arena occludes it underneath.
	for grid_index: int in range(-18, 19):
		var x_pos: float = float(grid_index) * 10.0
		var x_line := BoxMesh.new()
		x_line.size = Vector3(0.035, 0.012, 400.0)
		_add_world_mesh(decor, "OuterGridX_%d" % grid_index, x_line, Vector3(x_pos, -0.19, 32.0), outer_grid_material)
	for grid_index: int in range(-18, 19):
		var z_pos: float = 32.0 + float(grid_index) * 10.0
		var z_line := BoxMesh.new()
		z_line.size = Vector3(400.0, 0.012, 0.035)
		_add_world_mesh(decor, "OuterGridZ_%d" % grid_index, z_line, Vector3(0.0, -0.19, z_pos), outer_grid_material)

	# Circuit-board traces outside the play area add visual detail to the surrounding floor.
	for side: float in [-1.0, 1.0]:
		for row_index: int in range(3):
			var trace_x: float = side * (42.0 + float(row_index) * 12.0)
			var trace_z: float = -8.0 + float(row_index) * 27.0
			var trace_a := BoxMesh.new()
			trace_a.size = Vector3(0.07, 0.018, 20.0 + float(row_index) * 5.0)
			_add_world_mesh(decor, "CircuitTraceVertical", trace_a, Vector3(trace_x, -0.17, trace_z), circuit_cyan if row_index % 2 == 0 else circuit_magenta)
			var trace_b := BoxMesh.new()
			trace_b.size = Vector3(13.0, 0.018, 0.07)
			_add_world_mesh(decor, "CircuitTraceHorizontal", trace_b, Vector3(trace_x + side * 6.5, -0.17, trace_z - 10.0 - float(row_index) * 2.5), circuit_cyan if row_index % 2 == 0 else circuit_magenta)
			var trace_node := SphereMesh.new()
			trace_node.radius = 0.16
			trace_node.height = 0.32
			_add_world_mesh(decor, "CircuitNode", trace_node, Vector3(trace_x, -0.14, trace_z), post_light_material)

	# Distant TRON megastructure: intentionally taller and more architectural than
	# the flat arena floor, so the playable space reads as a platform in a larger world.
	var tower_body_material := _material(Color("111a35"), Color("171d4c"))
	var tower_cyan_material := _material(Color("29e7ff"), Color("0bcfff"))
	var tower_violet_material := _material(Color("a64dff"), Color("8529ff"))
	var tower_magenta_material := _material(Color("ff43d0"), Color("ff16b8"))
	_outer_pulse_materials.append(tower_cyan_material)
	_outer_pulse_materials.append(tower_violet_material)
	_outer_pulse_materials.append(tower_magenta_material)
	# Build a skyline beyond the arena edges. These are decorative only and have no collision.
	var skyline_positions: Array[Vector3] = [
		Vector3(-48.0, 0.0, -22.0), Vector3(-76.0, 0.0, 8.0), Vector3(-58.0, 0.0, 83.0),
		Vector3(-92.0, 0.0, 48.0), Vector3(48.0, 0.0, -24.0), Vector3(78.0, 0.0, 12.0),
		Vector3(56.0, 0.0, 86.0), Vector3(96.0, 0.0, 48.0), Vector3(-18.0, 0.0, -43.0),
		Vector3(22.0, 0.0, -48.0), Vector3(-22.0, 0.0, 112.0), Vector3(24.0, 0.0, 116.0)
	]
	for tower_index: int in range(skyline_positions.size()):
		var tower_height: float = 7.0 + float((tower_index * 7) % 11)
		var tower_width: float = 1.2 + float(tower_index % 3) * 0.45
		var tower_root := Node3D.new()
		tower_root.name = "OuterNeonTower_%02d" % tower_index
		tower_root.position = skyline_positions[tower_index]
		decor.add_child(tower_root)
		var tower_mesh := BoxMesh.new()
		tower_mesh.size = Vector3(tower_width, tower_height, tower_width)
		_add_world_mesh(tower_root, "TowerCore", tower_mesh, Vector3(0.0, tower_height * 0.5 - 0.2, 0.0), tower_body_material)
		# Offset luminous strips break up the silhouette like futuristic building facades.
		var strip_mesh := BoxMesh.new()
		strip_mesh.size = Vector3(tower_width + 0.08, 0.12, tower_width + 0.08)
		var strip_material: StandardMaterial3D = tower_cyan_material if tower_index % 3 == 0 else (tower_violet_material if tower_index % 3 == 1 else tower_magenta_material)
		for strip_index: int in range(2):
			_add_world_mesh(tower_root, "FacadeLight_%d" % strip_index, strip_mesh, Vector3(0.0, 1.3 + float(strip_index) * tower_height * 0.43, 0.0), strip_material)
		var top_light := SphereMesh.new()
		top_light.radius = 0.32 + float(tower_index % 3) * 0.08
		top_light.height = top_light.radius * 2.0
		_add_world_mesh(tower_root, "TowerBeacon", top_light, Vector3(0.0, tower_height + 0.1, 0.0), strip_material)
		# Rotating holographic fins sit around the upper third of each tower.
		var fin_orbit := Node3D.new()
		fin_orbit.name = "HolographicFinOrbit"
		fin_orbit.position = Vector3(0.0, tower_height * 0.72, 0.0)
		tower_root.add_child(fin_orbit)
		var fin := BoxMesh.new()
		fin.size = Vector3(tower_width * 2.8, 0.10, 0.18)
		_add_world_mesh(fin_orbit, "OrbitFin", fin, Vector3(tower_width * 1.45, 0.0, 0.0), strip_material)
		_outer_rotating_nodes.append(fin_orbit)

	# Large holographic orbital hoops in the far background distinguish it from the floor grid.
	for hoop_index: int in range(3):
		var hoop_root := Node3D.new()
		hoop_root.name = "DistantHologramHoop_%d" % hoop_index
		hoop_root.position = Vector3(0.0, 11.0 + float(hoop_index) * 5.5, 32.0)
		decor.add_child(hoop_root)
		var hoop := TorusMesh.new()
		hoop.outer_radius = 54.0 + float(hoop_index) * 13.0
		hoop.inner_radius = hoop.outer_radius - 0.12
		var hoop_material: StandardMaterial3D = tower_cyan_material if hoop_index % 2 == 0 else tower_violet_material
		var hoop_mesh := _add_world_mesh(hoop_root, "HologramHoop", hoop, Vector3.ZERO, hoop_material, Vector3(90.0, 0.0, 0.0))
		hoop_mesh.scale = Vector3(1.0, 0.72, 1.0)
		_outer_rotating_nodes.append(hoop_root)

	# Floating signal diamonds drift slowly above the outer circuit floor.
	for signal_index: int in range(10):
		var signal_node := Node3D.new()
		signal_node.name = "FloatingSignal_%02d" % signal_index
		signal_node.position = Vector3(-86.0 + float((signal_index * 37) % 172), 4.0 + float(signal_index % 4) * 2.0, -24.0 + float((signal_index * 29) % 120))
		decor.add_child(signal_node)
		var diamond := BoxMesh.new()
		diamond.size = Vector3(0.42, 0.42, 0.42)
		var signal_material: StandardMaterial3D = tower_magenta_material if signal_index % 3 == 0 else tower_cyan_material
		_add_world_mesh(signal_node, "SignalDiamond", diamond, Vector3.ZERO, signal_material, Vector3(45.0, 45.0, 0.0))
		_outer_float_nodes.append(signal_node)
		_outer_float_base_y.append(signal_node.position.y)
		_outer_rotating_nodes.append(signal_node)

	var center_z: float = (ARENA_MIN_Z + ARENA_MAX_Z) * 0.5
	var arena_width: float = ARENA_HALF_X * 2.0
	var arena_length: float = ARENA_MAX_Z - ARENA_MIN_Z

	# Subtle five-metre grid gives the floor depth and makes the space readable.
	for grid_index: int in range(-6, 7):
		var x_pos: float = float(grid_index) * 5.0
		var x_line := BoxMesh.new()
		x_line.size = Vector3(0.035 if grid_index % 2 != 0 else 0.055, 0.018, arena_length)
		_add_world_mesh(decor, "GridX_%d" % grid_index, x_line, Vector3(x_pos, 0.211, center_z), bright_grid_material if grid_index == 0 else grid_material)
	for grid_index: int in range(0, 13):
		var z_pos: float = ARENA_MIN_Z + float(grid_index) * 5.0
		var z_line := BoxMesh.new()
		z_line.size = Vector3(arena_width, 0.018, 0.035 if grid_index % 2 != 0 else 0.055)
		_add_world_mesh(decor, "GridZ_%d" % grid_index, z_line, Vector3(0.0, 0.211, z_pos), bright_grid_material if grid_index == 6 else grid_material)

	# Animated TRON scan bars travel across the floor. They are decorative only.
	_tron_scanline_nodes.clear()
	var scanline_cyan := _material(Color("28dfff"), Color("20cfff"))
	scanline_cyan.emission_energy_multiplier = 2.4
	var scanline_magenta := _material(Color("ff3bce"), Color("ff19b8"))
	scanline_magenta.emission_energy_multiplier = 2.0
	for scan_index: int in range(3):
		var scanline := Node3D.new()
		scanline.name = "AnimatedTRONScanline_%d" % scan_index
		scanline.position = Vector3(0.0, 0.235, ARENA_MIN_Z + 7.0 + float(scan_index) * 19.0)
		decor.add_child(scanline)
		var cyan_line := BoxMesh.new()
		cyan_line.size = Vector3(arena_width - 1.0, 0.018, 0.075)
		_add_world_mesh(scanline, "CyanScanline", cyan_line, Vector3.ZERO, scanline_cyan)
		var magenta_segment := BoxMesh.new()
		magenta_segment.size = Vector3(8.0, 0.021, 0.10)
		_add_world_mesh(scanline, "MagentaScanSegment", magenta_segment, Vector3(-12.0 + float(scan_index) * 12.0, 0.004, 0.08), scanline_magenta)
		_tron_scanline_nodes.append(scanline)

	# Luminous boundary rails and corner beacons mark the safe flight volume.
	for x_side: float in [-1.0, 1.0]:
		var side_rail := BoxMesh.new()
		side_rail.size = Vector3(0.16, 0.08, arena_length)
		_add_world_mesh(decor, "BoundaryX_%s" % str(x_side), side_rail, Vector3(x_side * ARENA_HALF_X, 0.26, center_z), border_material)
	for z_side: float in [ARENA_MIN_Z, ARENA_MAX_Z]:
		var end_rail := BoxMesh.new()
		end_rail.size = Vector3(arena_width, 0.08, 0.16)
		_add_world_mesh(decor, "BoundaryZ_%s" % str(z_side), end_rail, Vector3(0.0, 0.26, z_side), border_material)
	for x_side: float in [-1.0, 1.0]:
		for z_side: float in [ARENA_MIN_Z, ARENA_MAX_Z]:
			var post := CylinderMesh.new()
			post.top_radius = 0.16
			post.bottom_radius = 0.23
			post.height = 2.0
			_add_world_mesh(decor, "CornerBeacon", post, Vector3(x_side * ARENA_HALF_X, 1.15, z_side), post_material)
			var beacon_top := SphereMesh.new()
			beacon_top.radius = 0.22
			beacon_top.height = 0.44
			_add_world_mesh(decor, "BeaconLight", beacon_top, Vector3(x_side * ARENA_HALF_X, 2.22, z_side), post_light_material)

func _route_is_clear_of_obstacle(obstacle_position: Vector3, radius: float) -> bool:
	var route_points: Array[Vector3] = [start_position]
	for point: Vector3 in checkpoints:
		route_points.append(point)
	if goal_position != Vector3.ZERO:
		route_points.append(goal_position)

	var clearance: float = radius + ROUTE_CLEARANCE + DRONE_SAFE_RADIUS
	for point: Vector3 in route_points:
		if obstacle_position.distance_to(point) < clearance:
			return false

	for i: int in range(route_points.size() - 1):
		var a: Vector3 = route_points[i]
		var b: Vector3 = route_points[i + 1]
		var segment: Vector3 = b - a
		var length_squared: float = segment.length_squared()
		if length_squared <= 0.0001:
			continue
		var t: float = clampf((obstacle_position - a).dot(segment) / length_squared, 0.0, 1.0)
		var closest: Vector3 = a + segment * t
		if closest.distance_to(obstacle_position) < clearance:
			return false
	return true

func _generate_checkpoints() -> void:
	# Checkpoints are generated before obstacles, so the route can always be
	# made valid. Randomize the route, but fall back to a deterministic route
	# if random sampling ever fails.
	var attempts: int = 0
	while checkpoints.size() < CHECKPOINT_COUNT and attempts < CHECKPOINT_COUNT * 500:
		attempts += 1
		var candidate := Vector3(
			rng.randf_range(-ARENA_HALF_X + 5.0, ARENA_HALF_X - 5.0),
			rng.randf_range(MIN_ALTITUDE + 2.0, MAX_ALTITUDE - 2.0),
			rng.randf_range(ARENA_MIN_Z + 9.0, ARENA_MAX_Z - 7.0)
		)
		if candidate.distance_to(start_position) < MIN_CHECKPOINT_DISTANCE:
			continue
		if not _point_is_clear_of_checkpoints(candidate):
			continue
		var previous_point: Vector3 = start_position if checkpoints.is_empty() else checkpoints[checkpoints.size() - 1]
		if previous_point.distance_to(candidate) < MIN_CHECKPOINT_DISTANCE:
			continue
		checkpoints.append(candidate)

	# Guaranteed fallback: a simple forward route.
	var fallback_points: Array[Vector3] = [
		Vector3(-12.0, 9.0, 14.0),
		Vector3(12.0, 12.0, 24.0),
		Vector3(-12.0, 15.0, 34.0),
		Vector3(12.0, 12.0, 44.0),
		Vector3(0.0, 10.0, 54.0)
	]
	for candidate: Vector3 in fallback_points:
		if checkpoints.size() >= CHECKPOINT_COUNT:
			break
		if checkpoints.is_empty() or candidate.distance_to(checkpoints[checkpoints.size() - 1]) >= MIN_CHECKPOINT_DISTANCE:
			checkpoints.append(candidate)

	# This should never be reached, but guarantees the array length expected by
	# the scene even if the arena constants are changed later.
	while checkpoints.size() < CHECKPOINT_COUNT:
		var index: int = checkpoints.size()
		checkpoints.append(Vector3(0.0, 10.0, 12.0 + index * 10.0))

	for index: int in range(CHECKPOINT_COUNT):
		_configure_checkpoint(checkpoint_nodes[index], checkpoints[index], index)

func _point_is_clear_of_checkpoints(candidate: Vector3) -> bool:
	for existing: Vector3 in checkpoints:
		if candidate.distance_to(existing) < MIN_CHECKPOINT_DISTANCE:
			return false
	return true

func _point_is_clear_of_obstacles(candidate: Vector3, extra_distance: float) -> bool:
	for obstacle: Dictionary in obstacles:
		var obstacle_position: Vector3 = obstacle["position"] as Vector3
		var obstacle_radius: float = float(obstacle["radius"])
		if candidate.distance_to(obstacle_position) < obstacle_radius + extra_distance:
			return false
	return true

func _segment_is_clear_of_obstacles(a: Vector3, b: Vector3, clearance: float) -> bool:
	var segment: Vector3 = b - a
	var length_squared: float = segment.length_squared()
	if length_squared <= 0.0001:
		return true
	for obstacle: Dictionary in obstacles:
		var obstacle_position: Vector3 = obstacle["position"] as Vector3
		var obstacle_radius: float = float(obstacle["radius"]) + clearance + DRONE_SAFE_RADIUS
		var t: float = clampf((obstacle_position - a).dot(segment) / length_squared, 0.0, 1.0)
		var closest: Vector3 = a + segment * t
		if closest.distance_to(obstacle_position) < obstacle_radius:
			return false
	return true

func _configure_checkpoint(slot: Node3D, checkpoint_position: Vector3, index: int) -> void:
	slot.position = checkpoint_position
	slot.visible = false

	var ring: MeshInstance3D = slot.get_node("Ring") as MeshInstance3D
	if ring != null:
		ring.visible = true
		var ring_material := _material(Color("ffda68"), Color("ffb52e"))
		ring_material.metallic = 0.28
		ring_material.roughness = 0.2
		ring.material_override = ring_material
		# Add a thin inner accent hoop once per checkpoint for a layered sci-fi look.
		if slot.get_node_or_null("InnerAccentRing") == null:
			var accent := MeshInstance3D.new()
			accent.name = "InnerAccentRing"
			var accent_mesh := TorusMesh.new()
			accent_mesh.inner_radius = 2.12
			accent_mesh.outer_radius = 2.24
			accent.mesh = accent_mesh
			accent.rotation = ring.rotation
			accent.position = ring.position
			accent.material_override = _material(Color("62e7ff"), Color("23cfff"))
			slot.add_child(accent)

	var label: Label3D = slot.get_node("Label") as Label3D
	if label != null:
		label.text = "CHECKPOINT %02d" % (index + 1)
		label.modulate = Color("eafaff")

	var trigger: Area3D = slot.get_node("Trigger") as Area3D
	if trigger != null:
		trigger.monitoring = true
		trigger.monitorable = true

func _update_checkpoint_visibility() -> void:
	for index: int in range(checkpoint_nodes.size()):
		checkpoint_nodes[index].visible = index == checkpoint_index
	finish_root.visible = checkpoint_index >= CHECKPOINT_COUNT

func _check_checkpoint_distance() -> void:
	# Checkpoints are visual-only. They have NO physics collision.
	# Progress is detected only by distance to the center of the active ring.
	if checkpoint_index >= CHECKPOINT_COUNT:
		return
	var target: Vector3 = checkpoints[checkpoint_index]
	if drone.global_position.distance_to(target) <= CHECKPOINT_RADIUS:
		_activate_checkpoint(checkpoint_index)

func _activate_checkpoint(index: int) -> void:
	if episode_done or index != checkpoint_index:
		return
	reward = REWARD_CHECKPOINT
	last_checkpoint_reached = index + 1
	episode_checkpoint_count = max(episode_checkpoint_count, index + 1)
	checkpoint_nodes[index].visible = false
	checkpoint_index += 1

	if checkpoint_index < CHECKPOINT_COUNT:
		checkpoint_nodes[checkpoint_index].visible = true
		last_distance = drone.global_position.distance_to(checkpoints[checkpoint_index])
		info_label.text = "CHECKPOINT %d COMPLETE -> CHECKPOINT %d ACTIVE" % [index + 1, checkpoint_index + 1]
	else:
		finish_root.visible = true
		last_distance = drone.global_position.distance_to(goal_position)
		info_label.text = "CHECKPOINT 5 COMPLETE -> FINISH ACTIVE"

func _generate_finish() -> void:
	var attempts: int = 0
	while attempts < 300:
		attempts += 1
		var candidate := Vector3(
			rng.randf_range(-ARENA_HALF_X + 4.0, ARENA_HALF_X - 4.0),
			rng.randf_range(MIN_ALTITUDE + 2.0, MAX_ALTITUDE - 2.0),
			rng.randf_range(ARENA_MIN_Z + 7.0, ARENA_MAX_Z - 6.0)
		)
		var previous_point: Vector3 = checkpoints[CHECKPOINT_COUNT - 1]
		if _point_is_clear_of_checkpoints(candidate) and _point_is_clear_of_obstacles(candidate, OBSTACLE_MIN_DISTANCE_FROM_CHECKPOINT) and _segment_is_clear_of_obstacles(previous_point, candidate, ROUTE_CLEARANCE):
			goal_position = candidate
			break

	if goal_position == Vector3.ZERO:
		goal_position = checkpoints[CHECKPOINT_COUNT - 1] + Vector3(0.0, 0.0, 10.0)
		goal_position.x = clamp(goal_position.x, -ARENA_HALF_X + 4.0, ARENA_HALF_X - 4.0)
		goal_position.y = clamp(goal_position.y, MIN_ALTITUDE + 2.0, MAX_ALTITUDE - 2.0)
		goal_position.z = clamp(goal_position.z, ARENA_MIN_Z + 7.0, ARENA_MAX_Z - 6.0)

	finish_root.position = goal_position
	var ring: MeshInstance3D = finish_root.get_node("Ring") as MeshInstance3D
	if ring != null:
		ring.material_override = _material(Color("54e58c"), Color("54e58c"))
	var label: Label3D = finish_root.get_node("Label") as Label3D
	if label != null:
		label.text = "FINISH"
		label.modulate = Color("b9ffe0")

func _check_finish_distance() -> void:
	# Finish is visual-only. It also has NO physics collision.
	if checkpoint_index >= CHECKPOINT_COUNT and drone.global_position.distance_to(goal_position) <= FINISH_RADIUS:
		_complete_finish()

func _complete_finish() -> void:
	if episode_done:
		return
	var efficiency: float = 0.0
	if episode_travel_distance > 0.1 and episode_route_distance > 0.1:
		efficiency = clampf(episode_route_distance / episode_travel_distance, 0.0, 1.0)
	reward = REWARD_FINISH + REWARD_EFFICIENCY_BONUS * efficiency
	episode_done = true
	drone.stop()
	_record_episode_result(true, "finish")
	info_label.text = "LVL %d COMPLETE! +%d | EFF %.0f%% | SUCCESS %.0f%%" % [episode_start_level, int(reward), efficiency * 100.0, float(last_episode_stats.get("completed_level_success_rate", 0.0)) * 100.0]

func _check_physics_collisions() -> void:
	for collision_index: int in range(drone.get_slide_collision_count()):
		var collision: KinematicCollision3D = drone.get_slide_collision(collision_index)
		var collider: Object = collision.get_collider()
		if collider is Node and (collider as Node).is_in_group("drone_kill"):
			_kill_drone()
			return

func _check_environment_rules() -> void:
	var drone_position: Vector3 = drone.global_position
	if drone_position.x < -ARENA_HALF_X or drone_position.x > ARENA_HALF_X:
		_kill_drone()
		return
	if drone_position.z < ARENA_MIN_Z or drone_position.z > ARENA_MAX_Z:
		_kill_drone()
		return
	if drone_position.y < MIN_ALTITUDE or drone_position.y > MAX_ALTITUDE:
		_kill_drone()
		return

	for obstacle: Dictionary in obstacles:
		var obstacle_position: Vector3 = obstacle["position"] as Vector3
		var obstacle_radius: float = float(obstacle["radius"])
		if drone_position.distance_to(obstacle_position) <= obstacle_radius + DRONE_SAFE_RADIUS:
			_kill_drone()
			return

func _kill_drone() -> void:
	if episode_done:
		return
	reward = REWARD_DEATH
	episode_done = true
	drone.stop()
	_record_episode_result(false, "death")
	info_label.text = "DRONE DESTROYED! -300 | LVL %d | SUCCESS %.0f%%" % [episode_start_level, float(last_episode_stats.get("completed_level_success_rate", 0.0)) * 100.0]

func _current_target() -> Vector3:
	if checkpoint_index < CHECKPOINT_COUNT:
		return checkpoints[checkpoint_index]
	return goal_position

func step(action: int) -> Dictionary:
	if episode_done:
		return {"observation": get_observation(), "reward": reward, "done": true}

	var total_reward: float = 0.0
	last_checkpoint_reached = 0
	var previous_remaining_route: float = _remaining_route_distance()
	var step_travel_distance: float = 0.0
	episode_step_count += 1
	drone.manual_control = false

	# Short decisions near obstacles, long decisions in open space.
	var hold_ticks: int = RL_ACTION_HOLD_TICKS
	var short_hold: bool = false
	if _nearest_obstacle_distance() < OBSTACLE_INTERRUPT_DISTANCE:
		hold_ticks = NEAR_OBSTACLE_HOLD_TICKS
		short_hold = true
	var ticks_done: int = 0

	for _tick: int in range(hold_ticks):
		if episode_done:
			break

		if watch_active:
			await get_tree().create_timer(RL_SIM_DT / WATCH_SPEED).timeout
			if episode_done:
				break

		ticks_done += 1
		var previous_position: Vector3 = drone.global_position
		var collision: KinematicCollision3D = drone.simulate_rl_tick(action, RL_SIM_DT, _current_target())
		var tick_distance: float = previous_position.distance_to(drone.global_position)
		episode_travel_distance += tick_distance
		step_travel_distance += tick_distance
		episode_last_position = drone.global_position
		if collision != null:
			var collider: Object = collision.get_collider()
			if collider is Node and (collider as Node).is_in_group("drone_kill"):
				_kill_drone()
				total_reward += REWARD_DEATH
				break

		_check_physics_collisions()
		if episode_done:
			total_reward += REWARD_DEATH
			break

		_check_environment_rules()
		if episode_done:
			total_reward += REWARD_DEATH
			break

		var before_checkpoint: int = checkpoint_index
		_check_checkpoint_distance()
		if checkpoint_index > before_checkpoint:
			total_reward += REWARD_CHECKPOINT

		if not episode_done:
			_check_finish_distance()
			if episode_done:
				total_reward += reward

		if episode_done:
			break

		# Penalize closeness on every tick (not only at the end of the step), and
		# stop a long hold early if the drone has just entered the danger zone.
		var tick_nearest: float = _nearest_obstacle_distance()
		total_reward += _proximity_penalty(tick_nearest) / float(RL_ACTION_HOLD_TICKS)
		if not short_hold and tick_nearest < OBSTACLE_INTERRUPT_DISTANCE:
			break

	episode_sim_time += float(ticks_done) * RL_SIM_DT

	if not episode_done:
		var target: Vector3 = _current_target()
		var new_distance: float = drone.global_position.distance_to(target)
		var progress_reward: float = clampf((last_distance - new_distance) * REWARD_PROGRESS_SCALE, -2.5, 2.5)
		last_distance = new_distance

		# Reward reduction of the whole remaining route, not just the straight
		# line to the checkpoint. A good detour around an obstacle can temporarily
		# move sideways without being treated as completely wrong.
		var new_remaining_route: float = _remaining_route_distance()
		var route_progress_reward: float = clampf((previous_remaining_route - new_remaining_route) * 1.2, -2.0, 2.0)
		total_reward += progress_reward + route_progress_reward
		total_reward += REWARD_TIME

		# Penalize stalling more than exploration. This keeps the agent moving
		# toward a decision instead of hovering and waiting for luck.
		if step_travel_distance < 0.05:
			total_reward -= 0.5

		# NEW: stuck cutoff. If the remaining route distance has not improved
		# for STUCK_TICK_LIMIT physics ticks, end the episode as a failure.
		if new_remaining_route < best_remaining_route - 0.5:
			best_remaining_route = new_remaining_route
			ticks_since_progress = 0
		else:
			ticks_since_progress += ticks_done
			if ticks_since_progress >= STUCK_TICK_LIMIT:
				total_reward += REWARD_STUCK
				episode_done = true
				drone.stop()
				_record_episode_result(false, "stuck")
				info_label.text = "STUCK | LVL %d" % episode_start_level

	# Short-term action memory: remember whether the last chosen direction was
	# useful or dangerous. This is deliberately per-episode, so the policy can
	# learn patterns like "down just failed here; try above" without carrying a
	# stale bias from a completely different random map.
	var memory_feedback: float = 0.0
	if episode_done:
		if not last_episode_stats.is_empty() and bool(last_episode_stats.get("success", false)):
			memory_feedback = 1.0
		else:
			memory_feedback = -1.0
	else:
		var remaining_after_step: float = _remaining_route_distance()
		var route_delta: float = previous_remaining_route - remaining_after_step
		memory_feedback = clampf(route_delta / 3.0, -1.0, 1.0)
		var nearest_for_memory: float = _nearest_obstacle_distance()
		if nearest_for_memory < OBSTACLE_DANGER_DISTANCE:
			memory_feedback -= 0.35
		memory_feedback = clampf(memory_feedback, -1.0, 1.0)

	for memory_index: int in range(action_memory.size()):
		action_memory[memory_index] *= 0.97
	if action >= 0 and action < action_memory.size():
		action_memory[action] = clampf(lerpf(action_memory[action], memory_feedback, 0.45), -1.0, 1.0)

	reward = total_reward
	var response: Dictionary = {"observation": get_observation(), "reward": reward, "done": episode_done}
	var response_level: int = training_level
	var response_rate: float = _level_success_rate()
	var response_mean_checkpoints: float = _level_mean_checkpoints()
	var response_mean_efficiency: float = _level_mean_efficiency()
	var response_requirements_met: bool = _level_requirements_met()
	var response_window: int = level_results.size()
	if episode_done and not last_episode_stats.is_empty():
		response["episode_stats"] = last_episode_stats.duplicate(true)
		response_level = int(last_episode_stats.get("next_level", training_level))
		response_rate = float(last_episode_stats.get("level_success_rate", response_rate))
		response_mean_checkpoints = float(last_episode_stats.get("level_mean_checkpoints", response_mean_checkpoints))
		response_mean_efficiency = float(last_episode_stats.get("level_mean_efficiency", response_mean_efficiency))
		response_requirements_met = bool(last_episode_stats.get("level_requirements_met", response_requirements_met))
		response_window = int(last_episode_stats.get("level_window", response_window))
	response["level"] = response_level
	response["level_success_rate"] = response_rate
	response["level_mean_checkpoints"] = response_mean_checkpoints
	response["level_mean_efficiency"] = response_mean_efficiency
	response["level_requirements_met"] = response_requirements_met
	response["level_window"] = response_window
	response["training_complete"] = training_complete
	return response

func _proximity_penalty(nearest: float) -> float:
	var penalty: float = 0.0
	if nearest < OBSTACLE_WARNING_DISTANCE:
		var warning_ratio: float = (OBSTACLE_WARNING_DISTANCE - nearest) / OBSTACLE_WARNING_DISTANCE
		penalty -= REWARD_OBSTACLE_SCALE * warning_ratio * warning_ratio
	if nearest < OBSTACLE_DANGER_DISTANCE:
		var danger_ratio: float = (OBSTACLE_DANGER_DISTANCE - nearest) / OBSTACLE_DANGER_DISTANCE
		penalty -= REWARD_OBSTACLE_DANGER_SCALE * danger_ratio * danger_ratio
	return penalty

func get_observation() -> Array:
	var target: Vector3 = _current_target()
	var to_target: Vector3 = target - drone.global_position
	var horizontal_distance: float = Vector2(to_target.x, to_target.z).length()
	var target_direction: Vector3 = to_target.normalized() if to_target.length_squared() > 0.0001 else Vector3.ZERO

	var observation: Array = [
		drone.global_position.x / ARENA_HALF_X,
		(drone.global_position.y - MIN_ALTITUDE) / (MAX_ALTITUDE - MIN_ALTITUDE) * 2.0 - 1.0,
		(drone.global_position.z - ARENA_MIN_Z) / (ARENA_MAX_Z - ARENA_MIN_Z) * 2.0 - 1.0,
		clampf(drone.velocity.x / drone.speed, -1.0, 1.0),
		clampf(drone.velocity.y / drone.speed, -1.0, 1.0),
		clampf(drone.velocity.z / drone.speed, -1.0, 1.0),
		clampf(to_target.x / (ARENA_HALF_X * 2.0), -1.0, 1.0),
		clampf(to_target.y / (MAX_ALTITUDE - MIN_ALTITUDE), -1.0, 1.0),
		clampf(to_target.z / (ARENA_MAX_Z - ARENA_MIN_Z), -1.0, 1.0),
		clampf(horizontal_distance / (ARENA_HALF_X * 2.0), 0.0, 1.0),
		float(checkpoint_index) / float(CHECKPOINT_COUNT),
		float(episode_map_level - 1) / float(MAX_LEVEL - 1),
		target_direction.x,
		target_direction.y,
		target_direction.z
	]

	# Dense 3D obstacle sensing: 16 horizontal rays plus up/down. The old
	# 10-ray layout was too sparse, so the policy often had no useful signal
	# until it was already very close to an obstacle.
	for sensor_index: int in range(16):
		var angle: float = TAU * float(sensor_index) / 16.0
		var sensor_direction := Vector3(sin(angle), 0.0, cos(angle))
		observation.append(_obstacle_sensor(sensor_direction))
	observation.append(_obstacle_sensor(Vector3.UP))
	observation.append(_obstacle_sensor(Vector3.DOWN))

	# How much route is left gives PPO a stable long-horizon notion of the goal,
	# not just "fly toward this point".
	observation.append(clampf(_remaining_route_distance() / 120.0, 0.0, 1.0))

	var drone_position_for_observation: Vector3 = drone.global_position
	observation.append(clampf((drone_position_for_observation.x + ARENA_HALF_X) / (ARENA_HALF_X * 2.0), 0.0, 1.0))
	observation.append(clampf((ARENA_HALF_X - drone_position_for_observation.x) / (ARENA_HALF_X * 2.0), 0.0, 1.0))
	observation.append(clampf((drone_position_for_observation.y - MIN_ALTITUDE) / (MAX_ALTITUDE - MIN_ALTITUDE), 0.0, 1.0))
	observation.append(clampf((MAX_ALTITUDE - drone_position_for_observation.y) / (MAX_ALTITUDE - MIN_ALTITUDE), 0.0, 1.0))
	observation.append(clampf((drone_position_for_observation.z - ARENA_MIN_Z) / (ARENA_MAX_Z - ARENA_MIN_Z), 0.0, 1.0))
	observation.append(clampf((ARENA_MAX_Z - drone_position_for_observation.z) / (ARENA_MAX_Z - ARENA_MIN_Z), 0.0, 1.0))
	observation.append(clampf(_nearest_obstacle_distance() / 12.0, 0.0, 1.0))

	# Explicit absolute target information. The policy therefore always knows
	# where it is, where the current goal is, how far away it is, and how much
	# of the complete route remains.
	observation.append(clampf(target.x / ARENA_HALF_X, -1.0, 1.0))
	observation.append(clampf((target.y - MIN_ALTITUDE) / (MAX_ALTITUDE - MIN_ALTITUDE) * 2.0 - 1.0, -1.0, 1.0))
	observation.append(clampf((target.z - ARENA_MIN_Z) / (ARENA_MAX_Z - ARENA_MIN_Z) * 2.0 - 1.0, -1.0, 1.0))
	observation.append(clampf(to_target.length() / 80.0, 0.0, 1.0))
	var route_progress: float = 0.0
	if episode_route_distance > 0.1:
		route_progress = clampf(1.0 - (_remaining_route_distance() / episode_route_distance), 0.0, 1.0)
	observation.append(route_progress)
	observation.append(float(drone.rl_action) / 7.0)
	if drone.velocity.length_squared() > 0.01 and to_target.length_squared() > 0.01:
		observation.append(clampf(drone.velocity.normalized().dot(to_target.normalized()), -1.0, 1.0))
	else:
		observation.append(0.0)

	# Decision-aware lookahead: for each available action, expose two cheap
	# consequences of taking it for the next short move: target alignment and
	# obstacle clearance. PPO still chooses the action, but it no longer has to
	# discover from scratch which direction is obviously blocked. This makes
	# learning much more sample-efficient and supports the intended behaviour:
	# "straight is best when clear; otherwise choose the safest useful detour."
	for candidate_action: int in range(8):
		var candidate_direction: Vector3 = drone._goal_relative_direction(candidate_action, target)
		var candidate_clearance: float = 1.0 - _obstacle_sensor(candidate_direction)
		var candidate_alignment: float = candidate_direction.dot(target_direction) if target_direction.length_squared() > 0.01 else 0.0
		observation.append(clampf(candidate_alignment, -1.0, 1.0))
		observation.append(clampf(candidate_clearance, 0.0, 1.0))

	# Eight short-term action memories. Positive means the action recently made
	# useful progress; negative means it was dangerous or caused a failure.
	for memory_value: float in action_memory:
		observation.append(clampf(memory_value, -1.0, 1.0))

	return observation

func _obstacle_sensor(direction: Vector3) -> float:
	var max_distance: float = 12.0
	var nearest_distance: float = max_distance
	var origin: Vector3 = drone.global_position
	var ray_direction: Vector3 = direction.normalized()

	for obstacle: Dictionary in obstacles:
		var obstacle_position: Vector3 = obstacle["position"] as Vector3
		var relative: Vector3 = obstacle_position - origin
		var along: float = relative.dot(ray_direction)
		if along <= 0.0 or along > max_distance:
			continue

		var perpendicular: Vector3 = relative - ray_direction * along
		var obstacle_radius: float = float(obstacle["radius"]) + DRONE_SAFE_RADIUS
		if perpendicular.length() <= obstacle_radius:
			nearest_distance = minf(nearest_distance, maxf(0.0, along - obstacle_radius))

	# 1 = clear, 0 = obstacle immediately in this direction.
	return clampf(1.0 - nearest_distance / max_distance, 0.0, 1.0)

func _level_success_rate() -> float:
	if level_results.is_empty():
		return 0.0
	var successes: int = 0
	for result: bool in level_results:
		if result:
			successes += 1
	return float(successes) / float(level_results.size())

func _level_mean_checkpoints() -> float:
	if level_checkpoint_results.is_empty():
		return 0.0
	var total: float = 0.0
	for value: float in level_checkpoint_results:
		total += value
	return total / float(level_checkpoint_results.size())

func _level_mean_efficiency() -> float:
	if level_efficiency_results.is_empty():
		return 0.0
	var total: float = 0.0
	for value: float in level_efficiency_results:
		total += value
	return total / float(level_efficiency_results.size())

func _level_requirements_met() -> bool:
	return level_results.size() >= LEVEL_SUCCESS_WINDOW and _level_success_rate() >= LEVEL_SUCCESS_RATE_REQUIRED and _level_mean_checkpoints() >= LEVEL_MEAN_CHECKPOINTS_REQUIRED and _level_mean_efficiency() >= LEVEL_MEAN_EFFICIENCY_REQUIRED

func _record_episode_result(success: bool, reason: String) -> void:
	if not episode_started:
		return

	total_episodes += 1
	if success:
		total_successes += 1

	var episode_efficiency: float = clampf(episode_route_distance / maxf(episode_travel_distance, 0.1), 0.0, 1.0)

	# NEW: replay episodes (flown on an easier map) do not count toward promotion.
	var is_replay: bool = episode_map_level < training_level
	if not is_replay:
		level_results.append(success)
		level_checkpoint_results.append(float(episode_checkpoint_count))
		level_efficiency_results.append(episode_efficiency)
		if level_results.size() > LEVEL_SUCCESS_WINDOW:
			level_results.pop_front()
			level_checkpoint_results.pop_front()
			level_efficiency_results.pop_front()

	var completed_level: int = episode_start_level
	var rate: float = _level_success_rate()
	var mean_checkpoints: float = _level_mean_checkpoints()
	var mean_efficiency: float = _level_mean_efficiency()
	var requirements_met: bool = _level_requirements_met()
	var window_size: int = level_results.size()
	var promoted: bool = false

	if requirements_met and not is_replay:
		if training_level < MAX_LEVEL:
			training_level += 1
			promoted = true
		elif not training_complete:
			training_complete = true

	last_episode_stats = {
		"episode": total_episodes,
		"level": completed_level,
		"success": success,
		"reason": reason,
		"reward": reward,
		"lifetime_steps": episode_step_count,
		"lifetime_seconds": episode_sim_time,
		"travel_distance": episode_travel_distance,
		"route_distance": episode_route_distance,
		"efficiency": episode_efficiency,
		"checkpoints": episode_checkpoint_count,
		"level_success_rate": rate,
		"level_mean_checkpoints": mean_checkpoints,
		"level_mean_efficiency": mean_efficiency,
		"level_requirements_met": requirements_met,
		"level_window": window_size,
		"completed_level_success_rate": rate,
		"completed_level_mean_checkpoints": mean_checkpoints,
		"completed_level_mean_efficiency": mean_efficiency,
		"promoted": promoted,
		"training_complete": training_complete,
		"next_level": training_level
	}

	if promoted:
		print("[RL] LEVEL %d CLEARED: %.0f%% success, %.2f/5 mean checkpoints, %.0f%% mean efficiency over %d episodes -> LEVEL %d (%d obstacles)." % [completed_level, rate * 100.0, mean_checkpoints, mean_efficiency * 100.0, window_size, training_level, _obstacle_count_for_level(training_level)])
		level_results.clear()
		level_checkpoint_results.clear()
		level_efficiency_results.clear()
	elif training_complete:
		print("[RL] ALL 10 LEVELS CLEARED: >=70%% success, >=4.0/5 mean checkpoints, >=65%% mean efficiency. TRAINING COMPLETE.")

func _remaining_route_distance() -> float:
	var remaining: float = drone.global_position.distance_to(_current_target())
	if checkpoint_index < CHECKPOINT_COUNT:
		for i: int in range(checkpoint_index, CHECKPOINT_COUNT - 1):
			remaining += checkpoints[i].distance_to(checkpoints[i + 1])
		remaining += checkpoints[CHECKPOINT_COUNT - 1].distance_to(goal_position)
	return remaining

func _nearest_obstacle_distance() -> float:
	var nearest: float = 12.0
	var origin: Vector3 = drone.global_position
	for obstacle: Dictionary in obstacles:
		var obstacle_position: Vector3 = obstacle["position"] as Vector3
		var radius: float = float(obstacle["radius"]) + DRONE_SAFE_RADIUS
		nearest = minf(nearest, maxf(0.0, origin.distance_to(obstacle_position) - radius))
	return nearest

func _material(material_color: Color, emission_color: Color = Color.TRANSPARENT) -> StandardMaterial3D:
	var material := StandardMaterial3D.new()
	material.albedo_color = material_color
	material.metallic = 0.22
	material.roughness = 0.32
	if emission_color != Color.TRANSPARENT:
		material.emission_enabled = true
		material.emission = emission_color
		material.emission_energy_multiplier = 2.0
	return material
