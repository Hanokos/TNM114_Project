
from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np

from stable_baselines3 import PPO
from stable_baselines3.common.callbacks import BaseCallback, CheckpointCallback
from stable_baselines3.common.monitor import Monitor
from stable_baselines3.common.vec_env import (
    DummyVecEnv,
    SubprocVecEnv,
    VecNormalize,
)

from godot_env import GodotDroneEnv


# ----------------------------------------------------------------------------
# SETTINGS
# ----------------------------------------------------------------------------

# Choose:
# "train"    = create and train a completely NEW model
# "continue" = load an existing model and continue training it
# "test"     = test an existing model without training
MODE = "train"

# Existing model to load when MODE is "continue".
# Also used as the model to test when MODE is "test".
SOURCE_RUN_NAME = "baseline"

# Name of the output run.
# For "continue", use a DIFFERENT name to preserve your original model.
# For "train", this is the folder where the new model will be saved.
# For "test", this is the folder containing the model to test.
RUN_NAME = "newmnoielad_1"

N_ENVS = 1
BASE_PORT = 5000
SEED = 42

NET_ARCH = dict(pi=[256, 256], vf=[256, 256])

LR_START, LR_END = 3e-4, 5e-5
CLIP_START, CLIP_END = 0.2, 0.1

ENT_COEF = 0.01
N_STEPS_TOTAL = 4096
BATCH_SIZE = 512
N_EPOCHS = 5
TARGET_KL = 0.03

# Number of ADDITIONAL timesteps when training or continuing.
TOTAL_TIMESTEPS = 2_000_000


if MODE not in {"train", "continue", "test"}:
    raise ValueError('MODE must be "train", "continue", or "test".')

ROOT = Path(__file__).resolve().parent

MODEL_DIR = ROOT / "models" / RUN_NAME
LOG_DIR = ROOT / "logs" / RUN_NAME

SOURCE_MODEL_DIR = ROOT / "models" / SOURCE_RUN_NAME

MODEL_DIR.mkdir(parents=True, exist_ok=True)
LOG_DIR.mkdir(parents=True, exist_ok=True)

MODEL_PATH = MODEL_DIR / "drone_ppo_final"
VECNORMALIZE_PATH = MODEL_DIR / "vecnormalize.pkl"

SOURCE_MODEL_PATH = SOURCE_MODEL_DIR / "drone_ppo_final"
SOURCE_VECNORMALIZE_PATH = SOURCE_MODEL_DIR / "vecnormalize.pkl"

# Never accidentally overwrite the model we are continuing from.
if MODE == "continue" and RUN_NAME == SOURCE_RUN_NAME:
    raise ValueError(
        "RUN_NAME must differ from SOURCE_RUN_NAME when continuing "
        "training. For example, use SOURCE_RUN_NAME='baseline' and "
        "RUN_NAME='baseline_v2'."
    )


# ----------------------------------------------------------------------------
# STATISTICS CALLBACK
# ----------------------------------------------------------------------------

class CurriculumStatsCallback(BaseCallback):
    """Print curriculum and learning statistics after each PPO rollout."""

    def __init__(self, verbose: int = 0):
        super().__init__(verbose)

        self.rollout_number = 0
        self.batch_episodes: list[dict[str, Any]] = []
        self.all_episodes: list[dict[str, Any]] = []
        self.episode_counter = 0

    @staticmethod
    def _record_from_info(
        info: dict[str, Any],
        fallback_reward: float = 0.0,
        fallback_length: int = 0,
    ) -> dict[str, Any]:
        episode = info.get("episode", {}) or {}
        stats = info.get("episode_stats", {}) or {}

        return {
            "episode": int(stats.get("episode", 0)),
            "level": int(stats.get("level", info.get("level", 1))),
            "reward": float(episode.get("r", fallback_reward)),
            "lifetime_steps": int(
                stats.get("lifetime_steps", episode.get("l", fallback_length))
            ),
            "lifetime_seconds": float(stats.get("lifetime_seconds", 0.0)),
            "checkpoints": int(stats.get("checkpoints", 0)),
            "efficiency": float(stats.get("efficiency", 0.0)),
            "travel_distance": float(stats.get("travel_distance", 0.0)),
            "success": bool(
                stats.get("success", info.get("success", False))
            ),
            "reason": str(stats.get("reason", "unknown")),
            "level_success_rate": float(
                stats.get(
                    "level_success_rate",
                    info.get("level_success_rate", 0.0),
                )
            ),
            "level_mean_checkpoints": float(
                stats.get(
                    "level_mean_checkpoints",
                    info.get("level_mean_checkpoints", 0.0),
                )
            ),
            "level_mean_efficiency": float(
                stats.get(
                    "level_mean_efficiency",
                    info.get("level_mean_efficiency", 0.0),
                )
            ),
            "level_requirements_met": bool(
                stats.get(
                    "level_requirements_met",
                    info.get("level_requirements_met", False),
                )
            ),
            "level_window": int(
                stats.get("level_window", info.get("level_window", 0))
            ),
            "promoted": bool(stats.get("promoted", False)),
        }

    def _on_step(self) -> bool:
        infos = self.locals.get("infos", [])
        dones = self.locals.get("dones", [])
        rewards = self.locals.get("rewards", [])

        for index, (info, done) in enumerate(zip(infos, dones)):
            if not done:
                continue

            fallback_reward = (
                float(rewards[index]) if index < len(rewards) else 0.0
            )

            record = self._record_from_info(
                info,
                fallback_reward,
                int(info.get("step", 0)),
            )

            record["ppo_iteration"] = self.rollout_number + 1
            self.episode_counter += 1

            if record["episode"] <= 0:
                record["episode"] = self.episode_counter

            self.batch_episodes.append(record)
            self.all_episodes.append(record)

        for info in infos:
            if info.get("training_complete", False):
                self._print_final_report()
                return False

        return True

    @staticmethod
    def _fmt_time(seconds: float) -> str:
        if seconds <= 0.0:
            return "n/a"
        return f"{seconds:.1f}s"

    @staticmethod
    def _mean(records: list[dict[str, Any]], key: str) -> float:
        if not records:
            return 0.0
        return float(np.mean([float(record[key]) for record in records]))

    def _on_rollout_end(self) -> None:
        self.rollout_number += 1
        self._print_rollout_report()

    def _print_rollout_report(self) -> None:
        if not self.batch_episodes:
            print(
                f"\n[AI] PPO ITERATION {self.rollout_number} | "
                f"{self.num_timesteps:,} steps | "
                "no completed episodes in this batch"
            )
            return

        records = self.batch_episodes
        latest = records[-1]

        level = latest["level"]
        rate = latest["level_success_rate"]
        window = latest["level_window"]

        mean_reward = self._mean(records, "reward")
        mean_lifetime = self._mean(records, "lifetime_steps")
        mean_time = self._mean(records, "lifetime_seconds")
        mean_checkpoints = self._mean(records, "checkpoints")
        mean_efficiency = self._mean(records, "efficiency")

        success_rate = 100.0 * float(
            np.mean([1.0 if r["success"] else 0.0 for r in records])
        )

        best_reward = max(records, key=lambda r: r["reward"])
        best_lifetime = max(records, key=lambda r: r["lifetime_steps"])
        best_checkpoints = max(records, key=lambda r: r["checkpoints"])
        best_efficiency = max(records, key=lambda r: r["efficiency"])

        successful = [r for r in records if r["success"]]

        fastest_success = (
            min(successful, key=lambda r: r["lifetime_steps"])
            if successful
            else None
        )

        print("\n" + "=" * 72)
        print(
            f"AI TRAINING | PPO ITERATION {self.rollout_number} | "
            f"{self.num_timesteps:,} TOTAL STEPS"
        )
        print("=" * 72)

        mean_level_checkpoints = latest["level_mean_checkpoints"]
        mean_level_efficiency = latest["level_mean_efficiency"]

        level_obstacles = (
            round(5 + (level - 1) * 55 / 9) if level <= 10 else 60
        )

        print(f"LEVEL: {level}/10 | obstacles: {level_obstacles}")
        print(f"LEVEL WINDOW: {window}/100 completed episodes")
        print(f"  success              : {rate * 100:.1f}% / 70% required")
        print(
            f"  mean checkpoints     : "
            f"{mean_level_checkpoints:.2f} / 5 / 4.00 required"
        )
        print(
            f"  mean path efficiency : "
            f"{mean_level_efficiency * 100:.1f}% / 65% required"
        )

        print("\nMEAN — episodes completed in this PPO batch")
        print(f"  reward/score         : {mean_reward:+.2f}")
        print(
            f"  lifetime             : {mean_lifetime:.1f} RL steps "
            f"({self._fmt_time(mean_time)})"
        )
        print(f"  checkpoints          : {mean_checkpoints:.2f} / 5")
        print(f"  path efficiency      : {mean_efficiency * 100:.1f}%")
        print(f"  success rate         : {success_rate:.1f}%")

        print("\nBEST — inside this PPO batch")
        print(
            f"  best reward          : {best_reward['reward']:+.2f} "
            f"(episode {best_reward['episode']}, "
            f"PPO iter {best_reward['ppo_iteration']})"
        )
        print(
            f"  longest lifetime     : {best_lifetime['lifetime_steps']} "
            f"steps ({self._fmt_time(best_lifetime['lifetime_seconds'])}) "
            f"(episode {best_lifetime['episode']}, "
            f"PPO iter {best_lifetime['ppo_iteration']})"
        )
        print(
            f"  most checkpoints     : {best_checkpoints['checkpoints']} / 5 "
            f"(episode {best_checkpoints['episode']}, "
            f"PPO iter {best_checkpoints['ppo_iteration']})"
        )

        if fastest_success:
            print(
                f"  fastest finish       : "
                f"{fastest_success['lifetime_steps']} steps "
                f"({self._fmt_time(fastest_success['lifetime_seconds'])}) "
                f"(episode {fastest_success['episode']}, "
                f"PPO iter {fastest_success['ppo_iteration']})"
            )
        else:
            print("  fastest finish       : none yet")

        print(
            f"  best path efficiency : "
            f"{best_efficiency['efficiency'] * 100:.1f}% "
            f"(episode {best_efficiency['episode']}, "
            f"PPO iter {best_efficiency['ppo_iteration']})"
        )

        print("\nTOP 5 EPISODES — this PPO batch, ranked by reward")

        ranked = sorted(
            records,
            key=lambda r: r["reward"],
            reverse=True,
        )[:5]

        for rank, record in enumerate(ranked, start=1):
            status = (
                "FINISH" if record["success"] else record["reason"].upper()
            )

            print(
                f"  #{rank} ep {record['episode']:>5} | "
                f"iter {record['ppo_iteration']:>3} | "
                f"reward {record['reward']:+8.2f} | "
                f"life {record['lifetime_steps']:>4} | "
                f"CP {record['checkpoints']}/5 | {status}"
            )

        promoted_records = [r for r in records if r["promoted"]]

        if promoted_records:
            promoted = promoted_records[-1]

            print(
                f"\nLEVEL UP: Level {promoted['level']} cleared — "
                f"success {promoted['level_success_rate'] * 100:.0f}% + "
                f"checkpoints "
                f"{promoted['level_mean_checkpoints']:.2f}/5 + "
                f"efficiency "
                f"{promoted['level_mean_efficiency'] * 100:.0f}% "
                "-> next level."
            )
        elif latest["level_requirements_met"]:
            print(
                "\nLEVEL REQUIREMENTS MET — "
                "promotion will happen on the next reset."
            )
        elif mean_checkpoints > 0.0 or success_rate > 0.0:
            print(
                "\nGOAL LEARNING DETECTED — "
                "checkpoints/finishes are appearing."
            )
        else:
            print(
                "\nGOAL NOT REACHED IN THIS BATCH — "
                "keep training and watch the trend."
            )

        print("=" * 72)
        self.batch_episodes.clear()

    def _print_final_report(self) -> None:
        print("\n" + "#" * 72)
        print("TRAINING COMPLETE — ALL 10 LEVELS CLEARED AT >=70% SUCCESS")
        print("#" * 72)

        if not self.all_episodes:
            return

        top = sorted(
            self.all_episodes,
            key=lambda r: r["reward"],
            reverse=True,
        )[:5]

        print("TOP 5 EPISODES OF THE FULL TRAINING RUN")

        for rank, record in enumerate(top, start=1):
            status = (
                "FINISH" if record["success"] else record["reason"].upper()
            )

            print(
                f"  #{rank} ep {record['episode']:>5} | "
                f"level {record['level']} | "
                f"iter {record['ppo_iteration']:>3} | "
                f"reward {record['reward']:+8.2f} | "
                f"lifetime {record['lifetime_steps']:>4} | "
                f"CP {record['checkpoints']}/5 | {status}"
            )

        print("#" * 72)


# ----------------------------------------------------------------------------
# TRAINING CALLBACKS
# ----------------------------------------------------------------------------

def linear_schedule(start: float, end: float):
    """Decay from start to end as training progresses."""
    return lambda progress_remaining: (
        end + (start - end) * progress_remaining
    )


class LevelSnapshotCallback(BaseCallback):
    """Save a snapshot when the curriculum advances to a new level."""

    def __init__(self, save_path: Path):
        super().__init__()
        self.save_path = save_path
        self.last_level = 1

    def _on_step(self) -> bool:
        for info, done in zip(self.locals["infos"], self.locals["dones"]):
            if not done:
                continue

            level = int(info.get("level", 1))

            if level > self.last_level:
                self.model.save(
                    self.save_path / f"level_{self.last_level}_cleared"
                )
                self.last_level = level

        return True


class BestModelCallback(BaseCallback):
    """Save the model when the recent mean episode reward improves."""

    def __init__(self, save_path: Path, window: int = 50):
        super().__init__()
        self.save_path = save_path
        self.window = window
        self.rewards: list[float] = []
        self.best = -np.inf

    def _on_step(self) -> bool:
        for info, done in zip(self.locals["infos"], self.locals["dones"]):
            if done and "episode" in info:
                self.rewards.append(float(info["episode"]["r"]))

        if len(self.rewards) >= self.window:
            mean = float(np.mean(self.rewards[-self.window:]))

            if mean > self.best:
                self.best = mean
                self.model.save(self.save_path / "best_model")

        return True


# ----------------------------------------------------------------------------
# ENVIRONMENT
# ----------------------------------------------------------------------------

def make_env(rank: int):
    def _init():
        if N_ENVS == 1:
            env = GodotDroneEnv(max_steps=900)
        else:
            env = GodotDroneEnv(
                max_steps=900,
                port=BASE_PORT + rank,
            )

        return Monitor(
            env,
            filename=str(LOG_DIR / f"training_{rank}"),
        )

    return _init


# ----------------------------------------------------------------------------
# MAIN
# ----------------------------------------------------------------------------

def main() -> None:
    print(f"Mode: {MODE}")
    print(f"Output run name: {RUN_NAME}")

    if MODE in {"continue", "test"}:
        print(f"Source run name: {SOURCE_RUN_NAME}")

    print(
        f"Connects to Godot at 127.0.0.1:{BASE_PORT}"
        + (f"..{BASE_PORT + N_ENVS - 1}" if N_ENVS > 1 else "")
    )
    print("Start the Godot project first, then run this script.")

    if MODE in {"train", "continue"}:
        print(
            "Curriculum: 10 levels, 100-episode rolling window. "
            "Level-up requires >=70% success, >=4.0/5 mean checkpoints, "
            "and >=65% mean path efficiency."
        )
        print(
            "Learning aids: goal-relative actions, 8-action lookahead "
            "features, short-term action memory, and reward normalization."
        )

    if N_ENVS == 1:
        base_env = DummyVecEnv([make_env(0)])
    else:
        base_env = SubprocVecEnv(
            [make_env(i) for i in range(N_ENVS)]
        )

    # ------------------------------------------------------------------------
    # TEST MODE: load a saved model without training.
    # ------------------------------------------------------------------------

    if MODE == "test":
        if not SOURCE_MODEL_PATH.with_suffix(".zip").exists():
            base_env.close()
            raise FileNotFoundError(
                f"Saved model not found: {SOURCE_MODEL_PATH}.zip"
            )

        if not SOURCE_VECNORMALIZE_PATH.exists():
            base_env.close()
            raise FileNotFoundError(
                "Normalization statistics not found: "
                f"{SOURCE_VECNORMALIZE_PATH}"
            )

        env = VecNormalize.load(
            str(SOURCE_VECNORMALIZE_PATH),
            base_env,
        )
        env.training = False
        env.norm_reward = False

        model = PPO.load(
            SOURCE_MODEL_PATH,
            env=env,
            device="auto",
        )

        print(f"\nTesting saved model: {SOURCE_MODEL_PATH}.zip")
        print("Training is disabled. Press Ctrl+C to stop testing.")

        try:
            obs = env.reset()

            while True:
                action, _states = model.predict(
                    obs,
                    deterministic=True,
                )

                obs, rewards, dones, infos = env.step(action)

                for done, info in zip(dones, infos):
                    if done:
                        episode_stats = info.get("episode_stats", {})
                        episode_monitor = info.get("episode", {})

                        print(
                            "Episode finished | "
                            f"success={episode_stats.get('success', False)} | "
                            f"checkpoints={episode_stats.get('checkpoints', 0)} | "
                            f"reason={episode_stats.get('reason', 'unknown')} | "
                            f"reward={episode_monitor.get('r', 'n/a')}"
                        )

        except KeyboardInterrupt:
            print("\nTesting stopped.")

        finally:
            env.close()

        return

    # ------------------------------------------------------------------------
    # TRAIN / CONTINUE MODE: prepare normalization and callbacks.
    # ------------------------------------------------------------------------

    if MODE == "continue":
        if not SOURCE_MODEL_PATH.with_suffix(".zip").exists():
            base_env.close()
            raise FileNotFoundError(
                f"Model to continue was not found: {SOURCE_MODEL_PATH}.zip"
            )

        if not SOURCE_VECNORMALIZE_PATH.exists():
            base_env.close()
            raise FileNotFoundError(
                "Normalization statistics for the existing model "
                f"were not found: {SOURCE_VECNORMALIZE_PATH}"
            )

        # Load the saved observation/reward normalization statistics.
        # Keep updating them during training.
        env = VecNormalize.load(
            str(SOURCE_VECNORMALIZE_PATH),
            base_env,
        )
        env.training = True
        env.norm_reward = True

    else:
        # A new model starts with fresh normalization statistics.
        env = VecNormalize(
            base_env,
            norm_obs=False,
            norm_reward=True,
            clip_reward=10.0,
            gamma=0.995,
        )

    checkpoint = CheckpointCallback(
        save_freq=max(25_000 // N_ENVS, 1),
        save_path=str(MODEL_DIR),
        name_prefix="drone_ppo",
    )

    stats = CurriculumStatsCallback()
    best = BestModelCallback(MODEL_DIR)
    snapshots = LevelSnapshotCallback(MODEL_DIR)

    # ------------------------------------------------------------------------
    # LOAD EXISTING MODEL OR CREATE A NEW ONE.
    # ------------------------------------------------------------------------

    if MODE == "continue":
        model = PPO.load(
            SOURCE_MODEL_PATH,
            env=env,
            device="auto",
            tensorboard_log=str(LOG_DIR / "tensorboard"),
        )

        print("\n" + "=" * 72)
        print("CONTINUING TRAINING FROM AN EXISTING MODEL")
        print("=" * 72)
        print(f"Loaded model: {SOURCE_MODEL_PATH}.zip")
        print(f"Loaded normalization: {SOURCE_VECNORMALIZE_PATH}")
        print(f"New model will be saved to: {MODEL_PATH}.zip")
        print(f"Additional training steps: {TOTAL_TIMESTEPS:,}")
        print("The original model will not be overwritten.")
        print("=" * 72)

    else:
        model = PPO(
            "MlpPolicy",
            env,
            learning_rate=linear_schedule(LR_START, LR_END),
            n_steps=max(N_STEPS_TOTAL // N_ENVS, 64),
            batch_size=BATCH_SIZE,
            n_epochs=N_EPOCHS,
            gamma=0.995,
            gae_lambda=0.95,
            ent_coef=ENT_COEF,
            clip_range=linear_schedule(CLIP_START, CLIP_END),
            target_kl=TARGET_KL,
            max_grad_norm=0.5,
            policy_kwargs=dict(net_arch=NET_ARCH),
            seed=SEED,
            verbose=1,
            tensorboard_log=str(LOG_DIR / "tensorboard"),
            device="auto",
        )

        print("\nStarting NEW training from randomly initialized weights.")
        print(f"Model will be saved to: {MODEL_PATH}.zip")

    # ------------------------------------------------------------------------
    # TRAINING
    # ------------------------------------------------------------------------

    try:
        model.learn(
            total_timesteps=TOTAL_TIMESTEPS,
            callback=[checkpoint, stats, best, snapshots],
            progress_bar=False,
            reset_num_timesteps=(MODE == "train"),
        )

        # Save the final model and its updated normalization statistics.
        model.save(MODEL_PATH)
        env.save(str(VECNORMALIZE_PATH))

        print(f"\nTraining finished. Model saved to: {MODEL_PATH}.zip")
        print(
            "Normalization statistics saved to: "
            f"{VECNORMALIZE_PATH}"
        )

    finally:
        env.close()


if __name__ == "__main__":
    main()